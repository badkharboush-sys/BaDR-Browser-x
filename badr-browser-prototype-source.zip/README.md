# BaDR Guarded Browser — unfinished prototype

**Do not use this prototype for private or anonymous browsing.** It is not a release and has not been tested on an Android device. A signed experimental build was produced in the sandbox, but it is deliberately not included in this source archive.

## Status

The prototype contains Java source, English and Arabic resources, dark-and-gold artwork, and bundled filter data. Resource compilation and Java compilation succeeded. D8 and APK signature verification also succeeded for an experimental arm64 build. Eight small JVM domain-helper smoke tests passed. These checks do not establish that the app starts, that its UI works, or that traffic is protected.

## Release blockers

- Per-site proxy setup can fall back to direct connections and has not been shown to route all related requests or DNS safely. Navigation can start before Tor and proxy setup complete. This can expose the user's IP address. A fail-closed routing design and device-level network leak tests are required.
- This is not a system-wide VPN: there is no Android VpnService implementation. The UI's VPN label must not be interpreted as protection for other apps.
- Tor service configuration, bootstrapping, restart and control-port security require further integration work and device tests. The control port is currently configured without authentication. Do not use this on a device.
- The obfs4 executable is not bundled. Bridge modes are incomplete; placeholder default bridge entries have been removed. Do not rely on bridge or censorship-resistance features.
- Cleartext HTTP is disabled in the manifest, conflicting with the prototype's HTTP onion addresses. The filter loads asynchronously and its effectiveness is unverified; the abuse list can never be assumed comprehensive.
- The start-page actions and browser lifecycle need testing and completion. Feature labels and UI descriptions are aspirational, not verified guarantees.
- Manual APK packaging does not merge Android library resources and has not been validated for runtime compatibility. A successful build or signature check does not establish a working app.

## Build information

`tools/build.sh` is a work-in-progress manual build script. It expects Android platform 35 and build-tools 35, JDK 24, R8 9.5.32, and several AndroidX, Kotlin and Guardian Project artifacts already unpacked under `BADR_SDK` (default `~/.cache/sdk`). It does not fetch dependencies and is not yet a reproducible release build. The generated debug signing key is not a production key. The prototype packages only arm64 native Tor libraries.

Run the basic domain smoke tests using a JDK:

```
mkdir -p /tmp/badr-test
javac -encoding UTF-8 -d /tmp/badr-test app/src/main/java/com/badr/browser/Domains.java tools/DomainsSmokeTest.java
java -cp /tmp/badr-test com.badr.browser.DomainsSmokeTest
```

The bundled ad/tracker domain data derives from AdAway and Peter Lowe lists; see `tools/build_lists.py` for sources. The onion denylist was derived from Ahmia's public list. Confirm licenses and attribution requirements, refresh dates, and update mechanisms before distributing this software.
