#!/usr/bin/env python3
"""BaDR design generator.

Generates from one source of truth:
  design/logo/*.svg              - logo mark, wordmarks (EN + AR), app icon
  design/icons/*.svg             - UI icon set (gold preview SVGs)
  app/src/main/res/drawable/*.xml - Android VectorDrawables (logo, launcher layers, icons)

Text is converted to outlines (Playfair Display / Cinzel / Reem Kufi, SIL OFL) so the SVGs render the same everywhere.
Usage: python3 tools/gen_design.py [--fonts /path/with/Cinzel.ttf,ReemKufi.ttf]
"""
import os, re, sys, math

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
RES = os.path.join(ROOT, 'app', 'src', 'main', 'res', 'drawable')
DESIGN = os.path.join(ROOT, 'design')
FONT_DIR = os.environ.get('BADR_FONT_DIR', '/tmp')

GOLD = '#D4AF37'
GOLD_LIGHT = '#F1D27A'
BG = '#08080A'

# ----------------------------------------------------------------------------------------------
# Logo geometry (100 x 100 design space)
# ----------------------------------------------------------------------------------------------
SHIELD_OUT = ("M50 5 C62 11.5 75.5 13.5 88.5 13.5 L88.5 45 C88.5 70 72 86.5 50 95.5 "
              "C28 86.5 11.5 70 11.5 45 L11.5 13.5 C24.5 13.5 38 11.5 50 5 Z")
SHIELD_IN = ("M50 11.6 C61 17 72.4 19 82.6 19.3 L82.6 45.2 C82.6 66.2 68.8 80.6 50 88.8 "
             "C31.2 80.6 17.4 66.2 17.4 45.2 L17.4 19.3 C27.6 19 39 17 50 11.6 Z")
MOON_C = (50.0, 48.0)
MOON_R = 23.5


def circle_d(cx, cy, r):
    return (f"M{cx - r:g} {cy:g} A{r:g} {r:g} 0 1 0 {cx + r:g} {cy:g} "
            f"A{r:g} {r:g} 0 1 0 {cx - r:g} {cy:g} Z")


MOON = circle_d(*MOON_C, MOON_R)
# onion layers drawn as dark engraved lines on the gold full moon
ONION = [
    "M50 30.2 C51.2 35.6 62.2 40.2 62.2 51.2 C62.2 59.6 56.8 65.4 50 65.4 C43.2 65.4 37.8 59.6 37.8 51.2 C37.8 40.2 48.8 35.6 50 30.2 Z",
    "M50 38.6 C50.9 42.6 57.2 45.6 57.2 52.4 C57.2 57.8 54 61 50 61 C46 61 42.8 57.8 42.8 52.4 C42.8 45.6 49.1 42.6 50 38.6 Z",
    "M50 46.4 C50.5 48.8 52.7 50.2 52.7 53.6 C52.7 55.9 51.6 57.2 50 57.2 C48.4 57.2 47.3 55.9 47.3 53.6 C47.3 50.2 49.5 48.8 50 46.4 Z",
    "M50 30.2 C50.2 27.8 51.8 26.2 54.6 25.6",
]
SPARK = "M76 22.5 L77.1 25.4 L80 26.5 L77.1 27.6 L76 30.5 L74.9 27.6 L72 26.5 L74.9 25.4 Z"
SPARK2 = "M24.5 30 L25.2 31.8 L27 32.5 L25.2 33.2 L24.5 35 L23.8 33.2 L22 32.5 L23.8 31.8 Z"

GRAD_SHIELD = [(0, '#F8E6A0'), (0.42, '#DDB94F'), (0.78, '#A67E25'), (1, '#6F5114')]
GRAD_MOON = [(0, '#FFF6D2'), (0.38, '#F3D57E'), (0.72, '#D4AF37'), (1, '#93711D')]
GRAD_INNER = [(0, '#1D1B22'), (1, '#09090C')]


def svg_logo_mark(size=512, with_bg=False, rounded=0):
    s = size / 100.0
    bg = ''
    if with_bg:
        bg = (f'<rect width="100" height="100" rx="{rounded}" fill="url(#bgGrad)"/>')
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 100 100">
  <defs>
    <linearGradient id="shieldGrad" x1="0" y1="0" x2="0" y2="1">{''.join(f'<stop offset="{o}" stop-color="{c}"/>' for o, c in GRAD_SHIELD)}</linearGradient>
    <radialGradient id="innerGrad" cx="0.5" cy="0.35" r="0.75">{''.join(f'<stop offset="{o}" stop-color="{c}"/>' for o, c in GRAD_INNER)}</radialGradient>
    <radialGradient id="moonGrad" cx="0.38" cy="0.32" r="0.8">{''.join(f'<stop offset="{o}" stop-color="{c}"/>' for o, c in GRAD_MOON)}</radialGradient>
    <radialGradient id="bgGrad" cx="0.5" cy="0.42" r="0.7"><stop offset="0" stop-color="#1C1912"/><stop offset="1" stop-color="{BG}"/></radialGradient>
  </defs>
  {bg}
  <path d="{SHIELD_OUT}" fill="url(#shieldGrad)"/>
  <path d="{SHIELD_IN}" fill="url(#innerGrad)"/>
  <path d="{MOON}" fill="url(#moonGrad)"/>
  {''.join(f'<path d="{d}" fill="none" stroke="#17120A" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/>' for d in ONION)}
  <path d="{SPARK}" fill="{GOLD_LIGHT}"/>
  <path d="{SPARK2}" fill="{GOLD_LIGHT}" opacity="0.7"/>
</svg>
'''


def vd_gradient(kind, stops, **kw):
    attrs = ' '.join(f'android:{k}="{v}"' for k, v in kw.items())
    items = ''.join(f'\n          <item android:offset="{o}" android:color="#FF{c[1:]}"/>' for o, c in stops)
    return (f'\n      <aapt:attr name="android:fillColor">\n        <gradient android:type="{kind}" {attrs}>'
            f'{items}\n        </gradient>\n      </aapt:attr>')


def vd_logo_group(scale, tx, ty, mono=False):
    """VectorDrawable group drawing the logo mark (100-unit space) transformed into the viewport."""
    if mono:
        return f'''  <group android:scaleX="{scale}" android:scaleY="{scale}" android:translateX="{tx}" android:translateY="{ty}">
    <path android:fillColor="#FFFFFFFF" android:pathData="{SHIELD_OUT} {SHIELD_IN}" android:fillType="evenOdd"/>
    <path android:fillColor="#FFFFFFFF" android:pathData="{MOON}"/>
  </group>
'''
    onion = ''.join(f'''
    <path android:strokeColor="#FF17120A" android:strokeWidth="2.3" android:strokeLineCap="round" android:strokeLineJoin="round" android:pathData="{d}"/>''' for d in ONION)
    return f'''  <group android:scaleX="{scale}" android:scaleY="{scale}" android:translateX="{tx}" android:translateY="{ty}">
    <path android:pathData="{SHIELD_OUT}">{vd_gradient('linear', GRAD_SHIELD, startX=50, startY=5, endX=50, endY=95.5)}
    </path>
    <path android:pathData="{SHIELD_IN}">{vd_gradient('radial', GRAD_INNER, centerX=50, centerY=36, gradientRadius=60)}
    </path>
    <path android:pathData="{MOON}">{vd_gradient('radial', GRAD_MOON, centerX=44, centerY=40, gradientRadius=30)}
    </path>{onion}
    <path android:fillColor="#FFF1D27A" android:pathData="{SPARK}"/>
    <path android:fillColor="#B3F1D27A" android:pathData="{SPARK2}"/>
  </group>
'''


def vd_wrap(body, w, h, vw, vh, extra=''):
    return f'''<?xml version="1.0" encoding="utf-8"?>
<!-- Generated by tools/gen_design.py - do not edit by hand -->
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:aapt="http://schemas.android.com/aapt"
    android:width="{w}dp" android:height="{h}dp"
    android:viewportWidth="{vw}" android:viewportHeight="{vh}"{extra}>
{body}</vector>
'''


# ----------------------------------------------------------------------------------------------
# Text -> outline paths
# ----------------------------------------------------------------------------------------------
def text_path(text, font_file, size, wght=None, tracking=0.0, rtl=False):
    """Shape `text` with HarfBuzz and return (svg path d, advance width) at font `size` (y down, baseline 0)."""
    import uharfbuzz as hb
    from fontTools.ttLib import TTFont
    from fontTools.pens.svgPathPen import SVGPathPen
    from fontTools.pens.transformPen import TransformPen
    blob = hb.Blob.from_file_path(font_file)
    face = hb.Face(blob)
    font = hb.Font(face)
    if wght is not None:
        font.set_variations({'wght': wght})
    buf = hb.Buffer()
    buf.add_str(text)
    buf.guess_segment_properties()
    hb.shape(font, buf, {'kern': True, 'liga': True})
    tt = TTFont(font_file)
    if wght is not None and 'fvar' in tt:
        from fontTools.varLib import instancer
        tt = instancer.instantiateVariableFont(tt, {'wght': wght})
    upem = tt['head'].unitsPerEm
    gs = tt.getGlyphSet()
    order = tt.getGlyphOrder()
    sc = size / upem
    pen = SVGPathPen(gs)
    x = 0.0
    for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
        name = order[info.codepoint]
        tp = TransformPen(pen, (sc, 0, 0, -sc, (x + pos.x_offset) * sc, -pos.y_offset * sc))
        gs[name].draw(tp)
        x += pos.x_advance + tracking * upem
    d = pen.getCommands()
    return d, x * sc


def fmt_path(d):
    # compact numbers to keep the XML small
    return re.sub(r'-?\d+\.\d+', lambda m: f'{float(m.group()):.2f}'.rstrip('0').rstrip('.'), d)


# ----------------------------------------------------------------------------------------------
# Icon set (24 x 24, stroke icons). Feather-derived icons are MIT licensed (feathericons.com).
# ----------------------------------------------------------------------------------------------
ICONS = {
    'back': ['<line x1="20" y1="12" x2="5" y2="12"/>', '<polyline points="11 18 5 12 11 6"/>'],
    'forward': ['<line x1="4" y1="12" x2="19" y2="12"/>', '<polyline points="13 6 19 12 13 18"/>'],
    'reload': ['<polyline points="21 4 21 10 15 10"/>', '<path d="M19.1 15a8 8 0 1 1-1.9-8.3L21 10"/>'],
    'close': ['<line x1="18" y1="6" x2="6" y2="18"/>', '<line x1="6" y1="6" x2="18" y2="18"/>'],
    'star': ['<polygon points="12 2.8 14.8 8.5 21.1 9.4 16.5 13.8 17.6 20.1 12 17.1 6.4 20.1 7.5 13.8 2.9 9.4 9.2 8.5 12 2.8"/>'],
    'star_filled': ['<polygon fill="1" points="12 2.8 14.8 8.5 21.1 9.4 16.5 13.8 17.6 20.1 12 17.1 6.4 20.1 7.5 13.8 2.9 9.4 9.2 8.5 12 2.8"/>'],
    'share': ['<circle cx="18" cy="5" r="2.6"/>', '<circle cx="6" cy="12" r="2.6"/>', '<circle cx="18" cy="19" r="2.6"/>',
              '<line x1="8.4" y1="13.3" x2="15.6" y2="17.6"/>', '<line x1="15.6" y1="6.4" x2="8.4" y2="10.7"/>'],
    'link': ['<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7.1-7.1l-1.7 1.7"/>',
             '<path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7.1 7.1l1.7-1.7"/>'],
    'copy': ['<rect x="9" y="9" width="12" height="12" rx="2"/>', '<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>'],
    'search': ['<circle cx="11" cy="11" r="7"/>', '<line x1="20.5" y1="20.5" x2="16" y2="16"/>'],
    'find': ['<circle cx="10.5" cy="10.5" r="6.5"/>', '<line x1="20.5" y1="20.5" x2="15.3" y2="15.3"/>', '<line x1="7.8" y1="10.5" x2="13.2" y2="10.5"/>'],
    'text_size': ['<polyline points="3 7 3 4 13 4 13 7"/>', '<line x1="8" y1="4" x2="8" y2="19"/>', '<line x1="5.5" y1="19" x2="10.5" y2="19"/>',
                  '<polyline points="14 12 14 10 21 10 21 12"/>', '<line x1="17.5" y1="10" x2="17.5" y2="19"/>', '<line x1="16" y1="19" x2="19" y2="19"/>'],
    'desktop': ['<rect x="2" y="3.5" width="20" height="13" rx="2"/>', '<line x1="8" y1="20.5" x2="16" y2="20.5"/>', '<line x1="12" y1="16.5" x2="12" y2="20.5"/>'],
    'add_home': ['<rect x="3" y="3" width="18" height="18" rx="4"/>', '<line x1="12" y1="8" x2="12" y2="16"/>', '<line x1="8" y1="12" x2="16" y2="12"/>'],
    'external': ['<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>', '<polyline points="15 3 21 3 21 9"/>', '<line x1="10" y1="14" x2="21" y2="3"/>'],
    'shield': ['<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>'],
    'shield_check': ['<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>', '<polyline points="8.5 12 11 14.5 15.5 9.5"/>'],
    'shield_off': ['<path d="M19.7 14a6.9 6.9 0 0 0 .3-2V5l-8-3-3.2 1.2"/>', '<path d="M4.7 4.7L4 5v7c0 6 8 10 8 10a20.3 20.3 0 0 0 5.6-4.4"/>', '<line x1="2" y1="2" x2="22" y2="22"/>'],
    'lock': ['<rect x="4" y="11" width="16" height="10" rx="2"/>', '<path d="M8 11V7a4 4 0 0 1 8 0v4"/>'],
    'warning': ['<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>', '<line x1="12" y1="9" x2="12" y2="13"/>', '<line x1="12" y1="17" x2="12.01" y2="17"/>'],
    'info': ['<circle cx="12" cy="12" r="9.5"/>', '<line x1="12" y1="16" x2="12" y2="12"/>', '<line x1="12" y1="8" x2="12.01" y2="8"/>'],
    'tabs': ['<rect x="4" y="4" width="16" height="16" rx="3.5"/>'],
    'menu': ['<circle fill="1" cx="12" cy="5" r="1.7"/>', '<circle fill="1" cx="12" cy="12" r="1.7"/>', '<circle fill="1" cx="12" cy="19" r="1.7"/>'],
    'home': ['<path d="M3 10l9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>', '<polyline points="9 22 9 13 15 13 15 22"/>'],
    'download': ['<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>', '<polyline points="7 10 12 15 17 10"/>', '<line x1="12" y1="15" x2="12" y2="3"/>'],
    'settings': ['<circle cx="12" cy="12" r="3"/>', '<path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>'],
    'sliders': ['<line x1="4" y1="21" x2="4" y2="14"/>', '<line x1="4" y1="10" x2="4" y2="3"/>', '<line x1="12" y1="21" x2="12" y2="12"/>',
                '<line x1="12" y1="8" x2="12" y2="3"/>', '<line x1="20" y1="21" x2="20" y2="16"/>', '<line x1="20" y1="12" x2="20" y2="3"/>',
                '<line x1="1.5" y1="14" x2="6.5" y2="14"/>', '<line x1="9.5" y1="8" x2="14.5" y2="8"/>', '<line x1="17.5" y1="16" x2="22.5" y2="16"/>'],
    'history': ['<circle cx="12" cy="12" r="9.5"/>', '<polyline points="12 6.5 12 12 15.5 14"/>'],
    'bookmark': ['<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>'],
    'console': ['<rect x="2" y="3.5" width="20" height="17" rx="2.5"/>', '<polyline points="6.5 9 10 12 6.5 15"/>', '<line x1="12" y1="15.5" x2="17" y2="15.5"/>'],
    'code': ['<polyline points="16 18 22 12 16 6"/>', '<polyline points="8 6 2 12 8 18"/>'],
    'network': ['<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>'],
    'eye': ['<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>', '<circle cx="12" cy="12" r="3"/>'],
    'globe': ['<circle cx="12" cy="12" r="9.5"/>', '<line x1="2.5" y1="12" x2="21.5" y2="12"/>', '<path d="M12 2.5a14.5 14.5 0 0 1 3.8 9.5 14.5 14.5 0 0 1-3.8 9.5 14.5 14.5 0 0 1-3.8-9.5A14.5 14.5 0 0 1 12 2.5z"/>'],
    'trash': ['<polyline points="3 6 5 6 21 6"/>', '<path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>', '<path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>'],
    'plus': ['<line x1="12" y1="5" x2="12" y2="19"/>', '<line x1="5" y1="12" x2="19" y2="12"/>'],
    'pin': ['<path d="M20 10c0 6.5-8 12-8 12s-8-5.5-8-12a8 8 0 0 1 16 0z"/>', '<circle cx="12" cy="10" r="3"/>'],
    'power': ['<path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>', '<line x1="12" y1="2" x2="12" y2="12"/>'],
    'chevron_right': ['<polyline points="9 18 15 12 9 6"/>'],
    'chevron_down': ['<polyline points="6 9 12 15 18 9"/>'],
    'chevron_up': ['<polyline points="18 15 12 9 6 15"/>'],
    'check': ['<polyline points="20 6 9 17 4 12"/>'],
    'film': ['<rect x="2.5" y="3" width="19" height="18" rx="2.5"/>', '<line x1="7" y1="3" x2="7" y2="21"/>', '<line x1="17" y1="3" x2="17" y2="21"/>',
             '<line x1="2.5" y1="12" x2="21.5" y2="12"/>', '<line x1="2.5" y1="7.5" x2="7" y2="7.5"/>', '<line x1="2.5" y1="16.5" x2="7" y2="16.5"/>',
             '<line x1="17" y1="7.5" x2="21.5" y2="7.5"/>', '<line x1="17" y1="16.5" x2="21.5" y2="16.5"/>'],
    'music': ['<path d="M9 18V5l12-2v13"/>', '<circle cx="6" cy="18" r="3"/>', '<circle cx="18" cy="16" r="3"/>'],
    'file': ['<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/>', '<polyline points="13 2 13 9 20 9"/>'],
    'folder': ['<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>'],
    'exit': ['<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>', '<polyline points="16 17 21 12 16 7"/>', '<line x1="21" y1="12" x2="9" y2="12"/>'],
    'edit': ['<path d="M12 20h9"/>', '<path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>'],
    'block': ['<circle cx="12" cy="12" r="9.5"/>', '<line x1="5.3" y1="5.3" x2="18.7" y2="18.7"/>'],
    'moon': ['<path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/>'],
    'sparkle': ['<path d="M12 2.5l2 5.6 5.5 2-5.5 2L12 17.6l-2-5.5-5.5-2 5.5-2z"/>', '<path d="M19 15.5l.9 2.3 2.3.9-2.3.9-.9 2.3-.9-2.3-2.3-.9 2.3-.9z"/>'],
    'cookie': ['<path d="M21.5 12.5a9.5 9.5 0 1 1-10-10 3 3 0 0 0 3.5 3.5 3 3 0 0 0 3.5 3.5 3 3 0 0 0 3 3z"/>',
               '<line x1="8.5" y1="9" x2="8.51" y2="9"/>', '<line x1="8" y1="15" x2="8.01" y2="15"/>', '<line x1="13" y1="12.5" x2="13.01" y2="12.5"/>', '<line x1="15" y1="17" x2="15.01" y2="17"/>'],
    'onion': ['<path d="M12 3.6c.5 2.6 6.3 4.8 6.3 10.1 0 4.3-2.8 7.3-6.3 7.3s-6.3-3-6.3-7.3c0-5.3 5.8-7.5 6.3-10.1z"/>',
              '<path d="M12 8.4c.4 1.9 3.6 3.4 3.6 6.6 0 2.6-1.6 4.2-3.6 4.2s-3.6-1.6-3.6-4.2c0-3.2 3.2-4.7 3.6-6.6z"/>',
              '<path d="M12 13c.2 1 1.1 1.6 1.1 3 0 .9-.5 1.5-1.1 1.5s-1.1-.6-1.1-1.5c0-1.4.9-2 1.1-3z"/>',
              '<path d="M12 3.6c.2-1 1-1.7 2.4-2"/>'],
    'onion_tab': ['<rect x="2.5" y="4.5" width="19" height="15" rx="3"/>',
                  '<path d="M12 7.5c.3 1.4 3.3 2.4 3.3 5.2 0 2.2-1.5 3.8-3.3 3.8s-3.3-1.6-3.3-3.8c0-2.8 3-3.8 3.3-5.2z"/>'],
    'vpn': ['<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>', '<circle cx="12" cy="10.5" r="2.3"/>', '<line x1="12" y1="12.8" x2="12" y2="16"/>'],
    'signal': ['<line x1="5" y1="20" x2="5" y2="16"/>', '<line x1="10" y1="20" x2="10" y2="12"/>', '<line x1="15" y1="20" x2="15" y2="8"/>', '<line x1="20" y1="20" x2="20" y2="4"/>'],
    'bolt': ['<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>'],
    'play': ['<polygon points="6 3 20 12 6 21 6 3"/>'],
    'pause': ['<line x1="8" y1="4" x2="8" y2="20"/>', '<line x1="16" y1="4" x2="16" y2="20"/>'],
    'grid': ['<rect x="3" y="3" width="7.5" height="7.5" rx="1.5"/>', '<rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5"/>',
             '<rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5"/>', '<rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5"/>'],
    'language': ['<path d="M4 5h9"/>', '<path d="M8.5 3v2"/>', '<path d="M11 5c-1 4.5-4 8-7 9.5"/>', '<path d="M6 9c1.4 2.4 3.6 4.2 6 5"/>',
                 '<path d="M12.5 21l4-9 4 9"/>', '<path d="M14 17.8h5"/>'],
}
MIRRORED = {'back', 'forward', 'chevron_right', 'exit', 'external'}


def _nums(s):
    return [float(x) for x in re.findall(r'-?\d*\.?\d+(?:e-?\d+)?', s)]


def elem_to_path(el):
    tag = re.match(r'<(\w+)', el).group(1)
    attrs = dict(re.findall(r'(\w[\w-]*)="([^"]*)"', el))
    fill = 'fill' in attrs
    g = lambda k: float(attrs[k])
    if tag == 'path':
        d = attrs['d']
    elif tag == 'line':
        d = f"M{g('x1'):g} {g('y1'):g} L{g('x2'):g} {g('y2'):g}"
    elif tag in ('polyline', 'polygon'):
        p = _nums(attrs['points'])
        pts = [(p[i], p[i + 1]) for i in range(0, len(p), 2)]
        d = 'M' + ' L'.join(f'{x:g} {y:g}' for x, y in pts) + (' Z' if tag == 'polygon' else '')
    elif tag == 'circle':
        d = circle_d(g('cx'), g('cy'), g('r'))
    elif tag == 'rect':
        x, y, w, h = g('x'), g('y'), g('width'), g('height')
        r = float(attrs.get('rx', 0))
        if r:
            d = (f"M{x + r:g} {y:g} H{x + w - r:g} A{r:g} {r:g} 0 0 1 {x + w:g} {y + r:g} V{y + h - r:g} "
                 f"A{r:g} {r:g} 0 0 1 {x + w - r:g} {y + h:g} H{x + r:g} A{r:g} {r:g} 0 0 1 {x:g} {y + h - r:g} "
                 f"V{y + r:g} A{r:g} {r:g} 0 0 1 {x + r:g} {y:g} Z")
        else:
            d = f"M{x:g} {y:g} H{x + w:g} V{y + h:g} H{x:g} Z"
    else:
        raise ValueError(tag)
    return d, fill


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)


def gen_icons():
    for name, els in ICONS.items():
        paths = [elem_to_path(e) for e in els]
        svg_parts = []
        vd_parts = []
        for d, fill in paths:
            if fill:
                svg_parts.append(f'<path d="{d}" fill="currentColor" stroke="none"/>')
                vd_parts.append(f'  <path android:fillColor="#FFFFFFFF" android:pathData="{d}"/>\n')
            else:
                svg_parts.append(f'<path d="{d}"/>')
                vd_parts.append(f'  <path android:strokeColor="#FFFFFFFF" android:strokeWidth="1.8" android:strokeLineCap="round" '
                                f'android:strokeLineJoin="round" android:pathData="{d}"/>\n')
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" '
               f'stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="color:{GOLD}">'
               + ''.join(svg_parts) + '</svg>\n')
        write(os.path.join(DESIGN, 'icons', f'{name}.svg'), svg)
        extra = '\n    android:autoMirrored="true"' if name in MIRRORED else ''
        write(os.path.join(RES, f'ic_{name}.xml'), vd_wrap(''.join(vd_parts), 24, 24, 24, 24, extra))
    print('icons:', len(ICONS))


def gen_logo():
    write(os.path.join(DESIGN, 'logo', 'badr-mark.svg'), svg_logo_mark(512))
    write(os.path.join(DESIGN, 'logo', 'badr-app-icon.svg'), svg_logo_mark(512, with_bg=True, rounded=22))
    # in-app logo mark (vector)
    write(os.path.join(RES, 'logo_mark.xml'), vd_wrap(vd_logo_group(1, 0, 0), 96, 96, 100, 100))
    # adaptive launcher icon layers (108 x 108, safe zone = central 66)
    s = 0.6
    t = 54 - 50 * s
    write(os.path.join(RES, 'ic_launcher_foreground.xml'), vd_wrap(vd_logo_group(s, t, t + 0.5), 108, 108, 108, 108))
    write(os.path.join(RES, 'ic_launcher_monochrome.xml'), vd_wrap(vd_logo_group(s, t, t + 0.5, mono=True), 108, 108, 108, 108))
    bg = f'''  <path android:pathData="M0 0 H108 V108 H0 Z">{vd_gradient('radial', [(0, '#1E1A12'), (0.55, '#0F0E0D'), (1, '#060607')], centerX=54, centerY=46, gradientRadius=76)}
  </path>
'''
    write(os.path.join(RES, 'ic_launcher_background.xml'), vd_wrap(bg, 108, 108, 108, 108))

    # wordmarks
    cinzel = os.path.join(FONT_DIR, 'Cinzel.ttf')
    kufi = os.path.join(FONT_DIR, 'ReemKufi.ttf')
    if not (os.path.exists(cinzel) and os.path.exists(kufi)):
        print('fonts missing - skipping wordmarks')
        return
    playfair = os.path.join(FONT_DIR, 'Playfair.ttf')
    d_badr, w_badr = text_path('BaDR', playfair if os.path.exists(playfair) else cinzel, 66, wght=700, tracking=0.01)
    d_sub, w_sub = text_path('GUARDED BROWSER', cinzel, 15.5, wght=600, tracking=0.16)
    d_ar, w_ar = text_path('بدر', kufi, 58, wght=600)
    d_ar_sub, w_ar_sub = text_path('المتصفح المحمي', kufi, 19, wght=500)
    d_badr, d_sub, d_ar, d_ar_sub = map(fmt_path, (d_badr, d_sub, d_ar, d_ar_sub))
    grad = ''.join(f'<stop offset="{o}" stop-color="{c}"/>' for o, c in [(0, '#F8E6A0'), (0.5, '#D4AF37'), (1, '#9C7A22')])
    mark = svg_logo_mark(100).split('\n', 1)[1].rsplit('</svg>', 1)[0]
    W = 110 + max(w_badr, w_sub) + 10
    wordmark = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W * 2:.0f}" height="200" viewBox="0 0 {W:.1f} 100">
  <defs><linearGradient id="wm" x1="0" y1="0" x2="0" y2="1">{grad}</linearGradient></defs>
  <svg x="0" y="0" width="100" height="100" viewBox="0 0 100 100">{mark}</svg>
  <path transform="translate(108 62)" d="{d_badr}" fill="url(#wm)"/>
  <path transform="translate(110 84)" d="{d_sub}" fill="#BFA45A"/>
</svg>
'''
    write(os.path.join(DESIGN, 'logo', 'badr-wordmark.svg'), wordmark)
    Wa = 110 + max(w_ar, w_ar_sub) + 10
    wordmark_ar = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{Wa * 2:.0f}" height="200" viewBox="0 0 {Wa:.1f} 100">
  <defs><linearGradient id="wm" x1="0" y1="0" x2="0" y2="1">{grad}</linearGradient></defs>
  <path transform="translate({Wa - 110 - w_ar:.1f} 58)" d="{d_ar}" fill="url(#wm)"/>
  <path transform="translate({Wa - 110 - w_ar_sub:.1f} 86)" d="{d_ar_sub}" fill="#BFA45A"/>
  <svg x="{Wa - 100:.1f}" y="0" width="100" height="100" viewBox="0 0 100 100">{mark}</svg>
</svg>
'''
    write(os.path.join(DESIGN, 'logo', 'badr-wordmark-ar.svg'), wordmark_ar)
    # Android vector wordmark (text only) for in-app headers
    vw = max(w_badr, w_sub) + 4
    body = f'''  <group android:translateX="0" android:translateY="62">
    <path android:pathData="{d_badr}">{vd_gradient('linear', [(0, '#F8E6A0'), (0.5, '#D4AF37'), (1, '#9C7A22')], startX=0, startY=-50, endX=0, endY=0)}
    </path>
  </group>
  <group android:translateX="2" android:translateY="84">
    <path android:fillColor="#FFBFA45A" android:pathData="{d_sub}"/>
  </group>
'''
    write(os.path.join(RES, 'logo_wordmark.xml'), vd_wrap(body, round(vw * 0.5, 1), 46, round(vw, 1), 92))
    # export path data for the start page (inline SVG)
    write(os.path.join(ROOT, 'app', 'src', 'main', 'assets', 'web', 'logo.svg'), svg_logo_mark(96).replace('width="96" height="96" ', ''))
    print('logo + wordmarks written')


if __name__ == '__main__':
    gen_logo()
    gen_icons()
