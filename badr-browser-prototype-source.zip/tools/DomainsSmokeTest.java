package com.badr.browser;

/** Minimal JVM smoke tests, not security tests. */
public final class DomainsSmokeTest {
    private static void eq(String expected, String actual) {
        if (!expected.equals(actual)) throw new AssertionError("expected " + expected + ", got " + actual);
    }
    private static void yes(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        eq("example.com", Domains.hostOf("https://user@Example.COM:443/a"));
        eq("bbc.co.uk", Domains.site("news.bbc.co.uk"));
        eq("user.github.io", Domains.site("x.user.github.io"));
        eq("https://example.org", Domains.smartUrl("example.org", "https://search/?q=%s"));
        eq("https://search/?q=hello+world", Domains.smartUrl("hello world", "https://search/?q=%s"));
        eq("http://example.onion", Domains.smartUrl("example.onion", "https://search/?q=%s"));
        yes(Domains.isLocal("127.0.0.1"));
        yes(!Domains.safeForProxyRule("a.com/path"));
        System.out.println("8 domain smoke tests passed");
    }
}
