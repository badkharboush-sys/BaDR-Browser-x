#!/usr/bin/env python3
"""Builds the bundled filter assets for BaDR.

  assets/filters/builtin.txt  - ad/tracker domains (AdAway hosts CC BY 3.0 + Peter Lowe's list + extras)
  assets/filters/abuse.bin    - sorted 5-byte MD5 prefixes of onion hosts banned by Ahmia (CSAM blocklist)

Usage: python3 tools/build_lists.py <adaway.txt> <pgl.txt> <ahmia_banned.txt>
"""
import sys, os, hashlib
here = os.path.dirname(os.path.abspath(__file__))
out_dir = os.path.join(here, '..', 'app', 'src', 'main', 'assets', 'filters')
adaway, pgl, banned = sys.argv[1:4]

EXTRA = """mc.yandex.ru hilltopads.net adsterra.com trafficstars.com""".split()
# Never block these (they break many sites / link shorteners users click on purpose)
ALLOW = set("""t.co bit.ly facebook.com graph.facebook.com connect.facebook.net cdn.jsdelivr.net fonts.googleapis.com
ajax.googleapis.com gstatic.com youtube.com ytimg.com googlevideo.com amazonaws.com cloudfront.net akamaihd.net
twitter.com x.com recaptcha.net hcaptcha.com cloudflare.com cdnjs.cloudflare.com unpkg.com googleapis.com google.com
www.google.com github.com githubusercontent.com wikipedia.org""".split())

doms = set()
for line in open(adaway, errors='ignore'):
    p = line.split()
    if len(p) >= 2 and p[0] in ('127.0.0.1', '0.0.0.0') and p[1] != 'localhost':
        doms.add(p[1].lower())
for line in open(pgl, errors='ignore'):
    line = line.strip().lower()
    if line and not line.startswith('#'):
        doms.add(line)
doms |= set(EXTRA)
doms -= ALLOW
# drop sub-domains already covered by a parent entry
red = set()
for d in doms:
    parts = d.split('.')
    if not any('.'.join(parts[i:]) in doms for i in range(1, len(parts) - 1)):
        red.add(d)
with open(os.path.join(out_dir, 'builtin.txt'), 'w') as f:
    f.write('# BaDR built-in blocklist. Sources: AdAway hosts (CC BY 3.0, adaway.org), Peter Lowe\'s list (pgl.yoyo.org)\n')
    f.write('\n'.join(sorted(red)) + '\n')
print('builtin domains:', len(red))

prefixes = set()
for line in open(banned, errors='ignore'):
    h = line.strip().lower()
    if len(h) == 32 and all(c in '0123456789abcdef' for c in h):
        prefixes.add(bytes.fromhex(h)[:5])
# local supplement: onion hosts seen advertising child-abuse material in unfiltered search engines
for host in ["onlykidsx3k5izds7qoe2dznn7ghvxt6anmli6qltkct34wwnkz4iwad.onion"]:
    prefixes.add(hashlib.md5(host.encode()).digest()[:5])
with open(os.path.join(out_dir, 'abuse.bin'), 'wb') as f:
    for p in sorted(prefixes):
        f.write(p)
print('abuse prefixes:', len(prefixes))
