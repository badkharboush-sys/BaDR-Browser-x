#!/bin/bash
# BaDR offline build: aapt2 + javac + d8 + zipalign + apksigner (no Gradle, no network).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${BADR_SDK:-$HOME/.cache/sdk}"
BT="$SDK/bt/android-15"
PLAT="$SDK/plat/android-35"
M2="$SDK/m2"
APP="$ROOT/app/src/main"
OUT="$ROOT/build"
GEN="$OUT/gen"
CLASSES="$OUT/classes"
DEX="$OUT/dex"
APK="$OUT/badr-unsigned.apk"
SIGNED="$OUT/badr-EXPERIMENTAL-DO-NOT-USE.apk"
KS="$OUT/debug.keystore"
JAVAC="$SDK/jdk24/bin/javac"
JAVA="$SDK/jdk24/bin/java"
KEYTOOL="$SDK/jdk24/bin/keytool"
AAPT2="$BT/aapt2"
D8="$BT/d8"
ZIPALIGN="$BT/zipalign"
APKSIGNER="$BT/apksigner"
MIN_SDK=26

mkdir -p "$GEN" "$CLASSES" "$DEX"

echo "== 1. resources"
"$AAPT2" compile --dir "$APP/res" -o "$OUT/res.zip"
"$AAPT2" link -o "$APK" -I "$PLAT/android.jar" --manifest "$APP/AndroidManifest.xml" \
    --java "$GEN" --min-sdk-version $MIN_SDK --target-sdk-version 35 \
    --version-code 1 --version-name 1.0.0 -A "$APP/assets" "$OUT/res.zip"

echo "== 2. compile"
CP="$PLAT/android.jar"
for j in "$M2/tor-android.aar" "$M2/lbm.aar" "$M2/webkit.aar" "$M2/core.aar" "$M2/annotation-experimental.aar"; do
    CP="$CP:$M2/x/$(basename "$j" .aar)/classes.jar"
done
CP="$CP:$M2/jtorctl.jar:$M2/kotlin-stdlib.jar:$M2/annotation.jar"
SRCS=$(find "$APP/java" "$GEN" -name '*.java')
"$JAVAC" -encoding UTF-8 -source 8 -target 8 -nowarn -cp "$CP" -d "$CLASSES" $SRCS

echo "== 3. dex"
"$SDK/jdk24/bin/jar" cf "$OUT/app-classes.jar" -C "$CLASSES" .
export JAVA_HOME="$SDK/jdk24"
export PATH="$JAVA_HOME/bin:$PATH"
"$JAVA" -cp "$M2/r8.jar" com.android.tools.r8.D8 --release --min-api $MIN_SDK --output "$DEX" \
    "$OUT/app-classes.jar" "$M2/x/tor-android/classes.jar" "$M2/x/lbm/classes.jar" "$M2/x/webkit/classes.jar" \
    "$M2/x/core/classes.jar" "$M2/x/annotation-experimental/classes.jar" \
    "$M2/jtorctl.jar" "$M2/kotlin-stdlib.jar" "$M2/annotation.jar"

echo "== 4. native libs (arm64-v8a only, to keep the APK light)"
mkdir -p "$OUT/libs"
for abi in arm64-v8a; do
    mkdir -p "$OUT/libs/lib/$abi"
    cp "$M2/x/tor-android/jni/$abi/libtor.so" "$OUT/libs/lib/$abi/"
done

echo "== 5. package"
cd "$OUT/libs"
"$JAVA" -jar "$BT/lib/d8.jar" --version >/dev/null 2>&1 || true
zip -q -r "$APK" lib
cd "$ROOT"
zip -q -j "$APK" "$DEX/classes.dex"

echo "== 6. sign"
if [ ! -f "$KS" ]; then
    "$KEYTOOL" -genkeypair -keystore "$KS" -storepass badr1234 -keypass badr1234 -alias badr \
        -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=BaDR, O=BaDR, L=Cairo, ST=Cairo, C=EG" >/dev/null
fi
"$ZIPALIGN" -f 4 "$APK" "$OUT/badr-aligned.apk"
"$APKSIGNER" sign --ks "$KS" --ks-pass pass:badr1234 --key-pass pass:badr1234 \
    --out "$SIGNED" --v1-signing-enabled true --v2-signing-enabled true "$OUT/badr-aligned.apk"
"$APKSIGNER" verify --verbose "$SIGNED" | head -5
echo "== done: $SIGNED ($(stat -c%s "$SIGNED") bytes)"
