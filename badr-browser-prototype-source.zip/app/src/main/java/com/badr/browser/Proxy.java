package com.badr.browser;

import android.os.Handler;
import android.os.Looper;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;

import java.util.Set;
import java.util.concurrent.Executor;

/**
 * Per-site Tor routing through the WebView proxy override.
 *
 * The proxy override is app-wide, so we use reverse-bypass rules: everything goes direct EXCEPT the hosts
 * the user has switched on (plus every .onion host, which can only be reached through Tor anyway).
 * The override is applied only when the installed WebView supports it.
 */
final class Proxy {
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Executor exec = main::post;
    private boolean supported = true;
    private boolean applied;

    boolean isSupported() {
        return supported;
    }

    boolean isApplied() {
        return applied;
    }

    /** Build the proxy config: Tor SOCKS for the given hosts, direct for everything else. */
    static ProxyConfig buildConfig(int socksPort, Set<String> torHosts) {
        ProxyConfig.Builder b = new ProxyConfig.Builder();
        b.addProxyRule("socks://127.0.0.1:" + socksPort);
        b.addDirect();
        b.setReverseBypassEnabled(true);
        for (String h : torHosts) {
            if (h == null) continue;
            String host = h.trim().toLowerCase();
            if (host.isEmpty() || !Domains.safeForProxyRule(host)) continue;
            if (host.startsWith("*.")) {
                b.addBypassRule(host.substring(2));
            } else {
                b.addBypassRule(host);
            }
        }
        return b.build();
    }

    void apply(int socksPort, Set<String> torHosts, Runnable done) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            supported = false;
            if (done != null) done.run();
            return;
        }
        try {
            ProxyConfig cfg = buildConfig(socksPort, torHosts);
            ProxyController.getInstance().setProxyOverride(cfg, exec, () -> {
                applied = true;
                if (done != null) done.run();
            });
        } catch (Exception e) {
            supported = false;
            if (done != null) done.run();
        }
    }

    void clear(Runnable done) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            supported = false;
            if (done != null) done.run();
            return;
        }
        try {
            ProxyController.getInstance().clearProxyOverride(exec, () -> {
                applied = false;
                if (done != null) done.run();
            });
        } catch (Exception e) {
            if (done != null) done.run();
        }
    }
}
