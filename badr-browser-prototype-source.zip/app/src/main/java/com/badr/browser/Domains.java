package com.badr.browser;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** URL / host helpers. Pure Java so it can be unit-tested off-device. */
final class Domains {
    private Domains() {}

    /** Second-level labels that act as public suffixes under two-letter country TLDs (co.uk, com.eg ...). */
    private static final Set<String> SLD = new HashSet<>(Arrays.asList(
            "co", "com", "net", "org", "gov", "edu", "ac", "or", "ne", "go", "gob", "mil", "nic", "ltd", "plc",
            "sch", "info", "biz", "nom", "gen", "firm", "web"));
    /** Common hosting suffixes where every sub-domain is a different owner. */
    private static final Set<String> MULTI = new HashSet<>(Arrays.asList(
            "github.io", "gitlab.io", "blogspot.com", "appspot.com", "herokuapp.com", "vercel.app", "netlify.app",
            "pages.dev", "workers.dev", "web.app", "firebaseapp.com", "cloudfront.net", "azurewebsites.net",
            "s3.amazonaws.com", "glitch.me", "onrender.com", "fly.dev", "ngrok.io", "ngrok-free.app", "repl.co",
            "surge.sh", "neocities.org", "wordpress.com", "tumblr.com", "myshopify.com", "substack.com",
            "translate.goog", "supabase.co", "workers.dev", "deno.dev", "railway.app", "codeberg.page"));

    private static final Pattern IPV4 = Pattern.compile("^\\d{1,3}(\\.\\d{1,3}){3}$");
    private static final Pattern HOSTLIKE = Pattern.compile(
            "^[a-z0-9\\u00a1-\\uffff_-]+(\\.[a-z0-9\\u00a1-\\uffff_-]+)*\\.([a-z\\u00a1-\\uffff]{2,}|xn--[a-z0-9-]+)$");
    private static final Pattern SCHEME = Pattern.compile("^[a-zA-Z][a-zA-Z0-9+.-]*:.*");
    private static final Pattern RULE_SAFE = Pattern.compile("^[a-z0-9.-]+$|^\\[[0-9a-f:.]+]$");

    static String hostOf(String url) {
        if (url == null) return null;
        int s = url.indexOf("://");
        if (s < 0) return null;
        int start = s + 3;
        int end = url.length();
        for (int i = start; i < url.length(); i++) {
            char c = url.charAt(i);
            if (c == '/' || c == '?' || c == '#' || c == '\\') {
                end = i;
                break;
            }
        }
        String auth = url.substring(start, end);
        int at = auth.lastIndexOf('@');
        if (at >= 0) auth = auth.substring(at + 1);
        if (auth.startsWith("[")) {
            int rb = auth.indexOf(']');
            return rb > 0 ? auth.substring(0, rb + 1).toLowerCase(Locale.ROOT) : null;
        }
        int colon = auth.lastIndexOf(':');
        if (colon >= 0) auth = auth.substring(0, colon);
        while (auth.endsWith(".")) auth = auth.substring(0, auth.length() - 1);
        return auth.isEmpty() ? null : auth.toLowerCase(Locale.ROOT);
    }

    static String schemeOf(String url) {
        if (url == null) return "";
        int i = url.indexOf(':');
        return i > 0 ? url.substring(0, i).toLowerCase(Locale.ROOT) : "";
    }

    static boolean isHttp(String url) {
        String s = schemeOf(url);
        return "http".equals(s) || "https".equals(s);
    }

    static boolean isOnion(String host) {
        return host != null && (host.endsWith(".onion"));
    }

    static boolean isIp(String host) {
        return host != null && (IPV4.matcher(host).matches() || host.startsWith("["));
    }

    static boolean isLocal(String host) {
        if (host == null) return false;
        if (host.equals("localhost") || host.endsWith(".localhost") || host.endsWith(".local") || host.equals("[::1]"))
            return true;
        if (IPV4.matcher(host).matches()) {
            String[] p = host.split("\\.");
            int a = Integer.parseInt(p[0]), b = Integer.parseInt(p[1]);
            return a == 127 || a == 10 || (a == 192 && b == 168) || (a == 172 && b >= 16 && b <= 31) || (a == 169 && b == 254);
        }
        return false;
    }

    /** Registrable domain ("site") approximation: news.bbc.co.uk -> bbc.co.uk, a.b.example.com -> example.com. */
    static String site(String host) {
        if (host == null) return "";
        if (isIp(host) || host.indexOf('.') < 0) return host;
        String[] p = host.split("\\.");
        int n = p.length;
        if (n < 2) return host;
        String last2 = p[n - 2] + "." + p[n - 1];
        if (n >= 3) {
            if (MULTI.contains(last2)) return p[n - 3] + "." + last2;
            String last3 = p[n - 3] + "." + last2;
            if (n >= 4 && MULTI.contains(last3)) return p[n - 4] + "." + last3;
            if (p[n - 1].length() == 2 && SLD.contains(p[n - 2])) return last3;
        }
        return last2;
    }

    static String siteOfUrl(String url) {
        return site(hostOf(url));
    }

    static boolean safeForProxyRule(String host) {
        return host != null && host.length() < 254 && RULE_SAFE.matcher(host).matches();
    }

    /** Host for display, without a leading "www.". */
    static String displayHost(String url) {
        String h = hostOf(url);
        if (h == null) return url == null ? "" : url;
        return h.startsWith("www.") ? h.substring(4) : h;
    }

    static String encode(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return s;
        }
    }

    static String searchUrl(String template, String q) {
        return template.replace("%s", encode(q));
    }

    /**
     * Turns omnibox input into a URL. Returns a search URL (using {@code searchTemplate}) when the input
     * does not look like an address. Dangerous schemes are never loaded directly.
     */
    static String smartUrl(String input, String searchTemplate) {
        if (input == null) return null;
        String s = input.trim();
        if (s.isEmpty()) return null;
        String lower = s.toLowerCase(Locale.ROOT);
        if (lower.startsWith("javascript:") || lower.startsWith("file:") || lower.startsWith("content:")
                || lower.startsWith("intent:") || lower.startsWith("data:")) {
            return searchUrl(searchTemplate, s);
        }
        if (lower.startsWith("badr://") || lower.equals("about:blank")) return s;
        if (lower.startsWith("http://") || lower.startsWith("https://")) return s;
        if (s.indexOf(' ') >= 0) return searchUrl(searchTemplate, s);
        if (SCHEME.matcher(s).matches() && !lower.matches("^[^:/]+:\\d+(/.*)?$") && lower.contains("://")) {
            return s; // other explicit schemes (ftp://, etc.) are passed on and handled as external
        }
        String hostPart = s;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '/' || c == '?' || c == '#') {
                hostPart = s.substring(0, i);
                break;
            }
        }
        String h = hostPart.toLowerCase(Locale.ROOT);
        int at = h.lastIndexOf('@');
        if (at >= 0) h = h.substring(at + 1);
        int colon = h.lastIndexOf(':');
        if (colon > 0 && h.substring(colon + 1).matches("\\d{1,5}")) h = h.substring(0, colon);
        else if (colon > 0) return searchUrl(searchTemplate, s);
        if (h.equals("localhost") || isIp(h) || h.endsWith(".onion") || h.endsWith(".local")) return "http://" + s;
        if (HOSTLIKE.matcher(h).matches()) return "https://" + s;
        return searchUrl(searchTemplate, s);
    }

    /** "http://x" -> "https://x" */
    static String toHttps(String url) {
        return url.regionMatches(true, 0, "http://", 0, 7) ? "https://" + url.substring(7) : url;
    }

    static String toHttp(String url) {
        return url.regionMatches(true, 0, "https://", 0, 8) ? "http://" + url.substring(8) : url;
    }

    static String stripQuery(String url) {
        int q = url.indexOf('?');
        int h = url.indexOf('#');
        int cut = url.length();
        if (q >= 0) cut = Math.min(cut, q);
        if (h >= 0) cut = Math.min(cut, h);
        return url.substring(0, cut);
    }

    /** Lower-cased extension of the URL path ("" if none). */
    static String extension(String url) {
        String p = stripQuery(url);
        int slash = p.lastIndexOf('/');
        int dot = p.lastIndexOf('.');
        if (dot <= slash || dot < 0) return "";
        String e = p.substring(dot + 1).toLowerCase(Locale.ROOT);
        return e.length() > 6 ? "" : e;
    }
}
