package com.badr.browser;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Looper;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import org.torproject.jni.TorService;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Owns the Tor process (Guardian Project's tor-android) and exposes:
 *   - SOCKS / HTTP proxy ports for the WebView proxy override
 *   - circuit status, bootstrap progress, exit IP
 *   - NEWNYM (new identity), exit-country selection, obfs4 bridge support
 *
 * Tor is started with an explicit torrc so that bridges and the exit country are honoured.
 */
final class Tor {
    enum State { OFF, STARTING, ON, STOPPING }

    interface Listener {
        void onState(State s, int bootstrapPct, String detail);
    }

    private static final int SOCKS_PORT = 9050;
    private static final int HTTP_PORT = 8118;

    private final Context app;
    private final Prefs prefs;
    private final List<Listener> listeners = new CopyOnWriteArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Set<String> torHosts = Collections.synchronizedSet(new LinkedHashSet<String>());

    private volatile State state = State.OFF;
    private volatile int bootstrap = -1;
    private volatile String detail = "";
    private volatile int socksPort = SOCKS_PORT;
    private volatile int httpPort = HTTP_PORT;
    private volatile boolean starting;
    private volatile String exitIp = "";

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (i == null) return;
            String action = i.getAction();
            if (TorService.ACTION_STATUS.equals(action)) {
                String status = i.getStringExtra(TorService.EXTRA_STATUS);
                if (status == null) return;
                if (TorService.STATUS_ON.equals(status)) {
                    setState(State.ON, 100, "circuit established");
                    refreshPorts();
                    fetchExitIp();
                } else if (TorService.STATUS_STARTING.equals(status)) {
                    setState(State.STARTING, bootstrap, "starting");
                } else if (TorService.STATUS_OFF.equals(status)) {
                    setState(State.OFF, -1, "");
                }
            } else if (TorService.ACTION_ERROR.equals(action)) {
                String msg = i.getStringExtra("android.intent.extra.TEXT");
                setState(State.OFF, -1, msg == null ? "Tor failed to start" : msg);
            }
        }
    };

    Tor(Context c, Prefs p) {
        app = c.getApplicationContext();
        prefs = p;
        IntentFilter f = new IntentFilter(TorService.ACTION_STATUS);
        f.addAction(TorService.ACTION_ERROR);
        LocalBroadcastManager.getInstance(app).registerReceiver(receiver, f);
        new Thread(this::pollLoop, "badr-tor-poll").start();
    }

    void addListener(Listener l) {
        listeners.add(l);
        l.onState(state, bootstrap, detail);
    }

    void removeListener(Listener l) {
        listeners.remove(l);
    }

    State state() {
        return state;
    }

    boolean isOn() {
        return state == State.ON;
    }

    boolean isStarting() {
        return state == State.STARTING;
    }

    int socksPort() {
        return socksPort;
    }

    int httpPort() {
        return httpPort;
    }

    String exitIp() {
        return exitIp;
    }

    int bootstrap() {
        return bootstrap;
    }

    /** Hosts that must go through Tor (per-site toggle + onion search engines). */
    void setTorHosts(Set<String> hosts) {
        synchronized (torHosts) {
            torHosts.clear();
            for (String h : hosts) {
                if (h != null && Domains.safeForProxyRule(h)) torHosts.add(h);
            }
        }
    }

    Set<String> torHosts() {
        synchronized (torHosts) {
            return new LinkedHashSet<>(torHosts);
        }
    }

    void start() {
        if (starting || state == State.ON || state == State.STARTING) return;
        starting = true;
        setState(State.STARTING, -1, "starting");
        writeTorrc();
        try {
            app.startService(new Intent(app, TorService.class).setAction(TorService.ACTION_START));
        } catch (Exception e) {
            starting = false;
            setState(State.OFF, -1, "Tor could not start: " + e.getMessage());
        }
    }

    void stop() {
        try {
            app.startService(new Intent(app, TorService.class).setAction(TorService.ACTION_STOP));
        } catch (Exception ignored) {
        }
        setState(State.OFF, -1, "");
    }

    /** Ask Tor for a new circuit (new exit node / new identity). */
    void newIdentity() {
        if (state != State.ON) {
            start();
            return;
        }
        new Thread(() -> {
            try {
                org.torproject.jni.TorService svc = null;
                // The control connection lives inside the service; use the control socket via jtorctl.
                TorControl ctl = new TorControl(controlSocketFile());
                if (ctl.connect()) {
                    ctl.signal("NEWNYM");
                    ctl.close();
                    setState(State.STARTING, 0, "new identity requested");
                    fetchExitIp();
                }
            } catch (Exception ignored) {
            }
        }, "badr-newnym").start();
    }

    /** Apply a new exit country / bridge and restart Tor. */
    void applyConfigAndRestart() {
        if (state == State.OFF) return;
        stop();
        main.postDelayed(() -> {
            starting = false;
            start();
        }, 800);
    }

    private File controlSocketFile() {
        return new File(app.getFilesDir(), "torservice/TorService/ControlSocket");
    }

    private void refreshPorts() {
        try {
            Intent i = new Intent(app, TorService.class);
            // Ports are fixed by our torrc; nothing to read from the service.
            socksPort = SOCKS_PORT;
            httpPort = HTTP_PORT;
        } catch (Exception ignored) {
        }
    }

    private void fetchExitIp() {
        new Thread(() -> {
            String ip = TorHttp.get("http://check.torproject.org/api/ip", socksPort, 8000);
            if (ip != null) {
                int s = ip.indexOf('"');
                int e = ip.indexOf('"', s + 1);
                if (s >= 0 && e > s) {
                    String v = ip.substring(s + 1, e);
                    if (v.matches("\\d{1,3}(\\.\\d{1,3}){3}")) exitIp = v;
                }
            }
        }, "badr-exitip").start();
    }

    private void pollLoop() {
        while (true) {
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                return;
            }
            if (state == State.OFF) continue;
            TorControl ctl = new TorControl(controlSocketFile());
            if (!ctl.connect()) continue;
            try {
                String bs = ctl.getInfo("status/bootstrap-phase");
                if (bs != null && bs.contains("BOOTSTRAPPED")) {
                    int pct = parseBootstrap(bs);
                    if (pct >= 0 && pct != bootstrap) {
                        bootstrap = pct;
                        if (state == State.STARTING) setState(State.STARTING, pct, "bootstrap " + pct + "%");
                    }
                    if (pct >= 100 && state != State.ON) {
                        setState(State.ON, 100, "circuit established");
                        fetchExitIp();
                    }
                }
            } finally {
                ctl.close();
            }
        }
    }

    private static int parseBootstrap(String s) {
        int i = s.indexOf("PROGRESS=");
        if (i < 0) return -1;
        int j = i + 9;
        int k = j;
        while (k < s.length() && Character.isDigit(s.charAt(k))) k++;
        try {
            return Integer.parseInt(s.substring(j, k));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void setState(State s, int pct, String d) {
        state = s;
        if (pct >= 0) bootstrap = pct;
        if (s == State.OFF) bootstrap = -1;
        detail = d == null ? "" : d;
        if (s == State.ON) starting = false;
        if (s == State.OFF) starting = false;
        main.post(() -> {
            for (Listener l : listeners) l.onState(state, bootstrap, detail);
        });
    }

    private void writeTorrc() {
        StringBuilder sb = new StringBuilder();
        sb.append("SocksPort 127.0.0.1:").append(SOCKS_PORT).append("\n");
        sb.append("HTTPTunnelPort 127.0.0.1:").append(HTTP_PORT).append("\n");
        sb.append("ControlPort 127.0.0.1:9051\n");
        sb.append("CookieAuthentication 0\n");
        sb.append("RunAsDaemon 0\n");
        sb.append("AvoidDiskWrites 1\n");
        sb.append("ClientOnly 1\n");
        sb.append("LogMessageDomains 1\n");
        sb.append("TruncateLogFile 1\n");
        String country = prefs.exitCountry();
        if (country != null && !country.equals("auto") && country.length() == 2) {
            sb.append("ExitNodes {").append(country.toLowerCase()).append("} strict\n");
        }
        int transport = prefs.torTransport();
        String bridge = prefs.obfs4Bridge();
        if (transport == 2 || (transport == 0 && bridge != null && !bridge.trim().isEmpty())) {
            sb.append("ClientTransportPlugin obfs4 exec /data/data/").append(app.getPackageName())
                    .append("/files/torservice/obfs4proxy\n");
            sb.append("UseBridges 1\n");
            if (bridge != null) {
                for (String line : bridge.split("\n")) {
                    String t = line.trim();
                    if (t.startsWith("obfs4 ")) sb.append("Bridge ").append(t).append('\n');
                }
            }
        } else if (transport == 1) {
            sb.append("UseBridges 0\n");
        }
        try {
            File f = TorService.getTorrc(app);
            File parent = f.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            try (PrintWriter w = new PrintWriter(new FileWriter(f))) {
                w.print(sb.toString());
            }
        } catch (IOException ignored) {
        }
    }

    /** Minimal control-port client (jtorctl) used for bootstrap progress and NEWNYM. */
    static final class TorControl {
        private final File socket;
        private net.freehaven.tor.control.TorControlConnection conn;

        TorControl(File socket) {
            this.socket = socket;
        }

        boolean connect() {
            try {
                if (socket != null && socket.exists()) {
                    // jtorctl has no Unix-socket transport; fall back to the TCP control port.
                    conn = new net.freehaven.tor.control.TorControlConnection(
                            new java.net.Socket("127.0.0.1", 9051));
                } else {
                    conn = new net.freehaven.tor.control.TorControlConnection(
                            new java.net.Socket("127.0.0.1", 9051));
                }
                conn.authenticate(new byte[0]);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        String getInfo(String key) {
            try {
                return conn.getInfo(key);
            } catch (Exception e) {
                return null;
            }
        }

        void signal(String s) {
            try {
                conn.signal(s);
            } catch (Exception ignored) {
            }
        }

        void close() {
            try {
                if (conn != null) conn.closeStream("", (byte) 0);
            } catch (Exception ignored) {
            }
        }
    }

    /** Small HTTP-over-SOCKS helper (used for the exit-IP check and onion search). */
    static final class TorHttp {
        static String get(String url, int socksPort, int timeoutMs) {
            try {
                java.net.Proxy proxy = new java.net.Proxy(java.net.Proxy.Type.SOCKS,
                        new java.net.InetSocketAddress("127.0.0.1", socksPort));
                java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection(proxy);
                c.setConnectTimeout(timeoutMs);
                c.setReadTimeout(timeoutMs);
                c.setRequestProperty("User-Agent", "BaDR/1.0");
                if (c.getResponseCode() != 200) return null;
                try (java.io.InputStream in = c.getInputStream();
                     java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) >= 0) {
                        out.write(buf, 0, n);
                        if (out.size() > 2_000_000) break;
                    }
                    return out.toString("UTF-8");
                }
            } catch (Exception e) {
                return null;
            }
        }
    }

    /** No bundled bridges; configure verified bridge lines explicitly. */
    static List<String> defaultBridges() {
        return new ArrayList<>();
    }
}
