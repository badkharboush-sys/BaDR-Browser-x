package com.badr.browser;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/** Tiny SQLite store: bookmarks, history, per-site settings, downloads, console log. */
final class Db extends SQLiteOpenHelper {
    static final int V = 1;

    Db(Context c) {
        super(c, "badr.db", null, V);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE bookmarks(url TEXT PRIMARY KEY, title TEXT, ts INTEGER)");
        db.execSQL("CREATE TABLE history(url TEXT PRIMARY KEY, title TEXT, ts INTEGER, visits INTEGER)");
        db.execSQL("CREATE TABLE sites(site TEXT PRIMARY KEY, onion INTEGER, js INTEGER, desktop INTEGER, "
                + "cookies INTEGER, adblock INTEGER, https INTEGER)");
        db.execSQL("CREATE TABLE downloads(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT, name TEXT, "
                + "size INTEGER, status TEXT, ts INTEGER, onion INTEGER)");
        db.execSQL("CREATE TABLE console(id INTEGER PRIMARY KEY AUTOINCREMENT, level TEXT, text TEXT, ts INTEGER)");
        db.execSQL("CREATE INDEX idx_history_ts ON history(ts)");
        db.execSQL("CREATE INDEX idx_console_ts ON console(ts)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        onCreate(db);
    }

    // ---- bookmarks ----
    void addBookmark(String url, String title) {
        ContentValues v = new ContentValues();
        v.put("url", url);
        v.put("title", title == null ? url : title);
        v.put("ts", System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("bookmarks", null, v, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
    }

    void removeBookmark(String url) {
        getWritableDatabase().delete("bookmarks", "url=?", new String[]{url});
    }

    boolean isBookmarked(String url) {
        Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM bookmarks WHERE url=?", new String[]{url});
        boolean r = c.moveToFirst();
        c.close();
        return r;
    }

    List<String[]> bookmarks() {
        List<String[]> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT url,title FROM bookmarks ORDER BY ts DESC", null);
        while (c.moveToNext()) out.add(new String[]{c.getString(0), c.getString(1)});
        c.close();
        return out;
    }

    // ---- history ----
    void addHistory(String url, String title) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("title", title == null ? url : title);
        v.put("ts", System.currentTimeMillis());
        db.update("history", v, "url=?", new String[]{url});
        v.put("url", url);
        v.put("visits", 1);
        db.insertWithOnConflict("history", null, v, android.database.sqlite.SQLiteDatabase.CONFLICT_IGNORE);
    }

    List<String[]> history(int limit) {
        List<String[]> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT url,title FROM history ORDER BY ts DESC LIMIT " + Math.max(1, limit), null);
        while (c.moveToNext()) out.add(new String[]{c.getString(0), c.getString(1)});
        c.close();
        return out;
    }

    void clearHistory() {
        getWritableDatabase().delete("history", null, null);
    }

    // ---- per-site settings ----
    static final class Site {
        boolean onion, js = true, desktop, cookies = true, adblock = true, https = true;
    }

    Site site(String site) {
        Site s = new Site();
        Cursor c = getReadableDatabase().rawQuery("SELECT onion,js,desktop,cookies,adblock,https FROM sites WHERE site=?",
                new String[]{site});
        if (c.moveToFirst()) {
            s.onion = c.getInt(0) != 0;
            s.js = c.getInt(1) != 0;
            s.desktop = c.getInt(2) != 0;
            s.cookies = c.getInt(3) != 0;
            s.adblock = c.getInt(4) != 0;
            s.https = c.getInt(5) != 0;
        }
        c.close();
        return s;
    }

    void putSite(String site, Site s) {
        ContentValues v = new ContentValues();
        v.put("site", site);
        v.put("onion", s.onion ? 1 : 0);
        v.put("js", s.js ? 1 : 0);
        v.put("desktop", s.desktop ? 1 : 0);
        v.put("cookies", s.cookies ? 1 : 0);
        v.put("adblock", s.adblock ? 1 : 0);
        v.put("https", s.https ? 1 : 0);
        getWritableDatabase().insertWithOnConflict("sites", null, v, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);
    }

    List<String> onionSites() {
        List<String> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT site FROM sites WHERE onion=1", null);
        while (c.moveToNext()) out.add(c.getString(0));
        c.close();
        return out;
    }

    // ---- downloads ----
    long addDownload(String url, String name, boolean onion) {
        ContentValues v = new ContentValues();
        v.put("url", url);
        v.put("name", name);
        v.put("size", -1L);
        v.put("status", "queued");
        v.put("ts", System.currentTimeMillis());
        v.put("onion", onion ? 1 : 0);
        return getWritableDatabase().insert("downloads", null, v);
    }

    void setDownload(long id, long size, String status) {
        ContentValues v = new ContentValues();
        v.put("size", size);
        v.put("status", status);
        getWritableDatabase().update("downloads", v, "id=?", new String[]{String.valueOf(id)});
    }

    List<String[]> downloads() {
        List<String[]> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,url,name,size,status,ts,onion FROM downloads ORDER BY ts DESC LIMIT 200", null);
        while (c.moveToNext()) {
            out.add(new String[]{String.valueOf(c.getLong(0)), c.getString(1), c.getString(2),
                    String.valueOf(c.getLong(3)), c.getString(4), String.valueOf(c.getLong(5)),
                    String.valueOf(c.getInt(6))});
        }
        c.close();
        return out;
    }

    // ---- console ----
    void addConsole(String level, String text) {
        ContentValues v = new ContentValues();
        v.put("level", level);
        v.put("text", text);
        v.put("ts", System.currentTimeMillis());
        getWritableDatabase().insert("console", null, v);
    }

    List<String[]> console(int limit) {
        List<String[]> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT level,text,ts FROM console ORDER BY id DESC LIMIT " + Math.max(1, limit), null);
        while (c.moveToNext()) out.add(new String[]{c.getString(0), c.getString(1), String.valueOf(c.getLong(2))});
        c.close();
        return out;
    }

    int consoleCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM console", null);
        c.moveToFirst();
        int n = c.getInt(0);
        c.close();
        return n;
    }

    void clearConsole() {
        getWritableDatabase().delete("console", null, null);
    }
}
