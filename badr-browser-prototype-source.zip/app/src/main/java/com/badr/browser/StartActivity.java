package com.badr.browser;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/**
 * Start page: logo, search box, onion search, quick tiles and the Tor status card.
 */
public final class StartActivity extends Activity {
    private BadrApp app;
    private Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        app = BadrApp.get();
        prefs = app.prefs();

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);
        scroll.setFillViewport(true);
        LinearLayout root = Ui.vbox(this);
        root.setPadding(Ui.dp(this, 22), Ui.dp(this, 30), Ui.dp(this, 22), Ui.dp(this, 30));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_mark);
        root.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 96), Ui.dp(this, 96)));

        ImageView wordmark = new ImageView(this);
        wordmark.setImageResource(R.drawable.logo_wordmark);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(Ui.dp(this, 210), Ui.dp(this, 42));
        wp.setMargins(0, Ui.dp(this, 12), 0, Ui.dp(this, 4));
        root.addView(wordmark, wp);

        TextView tagline = Ui.text(this, getString(R.string.tagline), 13, Ui.TEXT2, false);
        tagline.setGravity(Gravity.CENTER);
        root.addView(tagline);

        // search box
        LinearLayout box = Ui.hbox(this);
        box.setBackground(Ui.roundStroke(Ui.SURFACE2, Ui.OUTLINE, Ui.dp(this, 1), Ui.dp(this, 26)));
        box.setPadding(Ui.dp(this, 18), Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
        EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setTextColor(Ui.TEXT);
        et.setHintTextColor(Ui.TEXT3);
        et.setTextSize(16);
        et.setBackground(null);
        et.setHint(getString(R.string.omnibox_hint));
        et.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        et.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO) {
                go(Domains.smartUrl(et.getText().toString(), prefs.searchEngine()));
                return true;
            }
            return false;
        });
        box.addView(et, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ImageView goBtn = Ui.icon(this, R.drawable.ic_search, Ui.GOLD, 22);
        goBtn.setOnClickListener(v -> go(Domains.smartUrl(et.getText().toString(), prefs.searchEngine())));
        box.addView(goBtn, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.setMargins(0, Ui.dp(this, 26), 0, 0);
        root.addView(box, bp);

        // onion search
        LinearLayout onionBox = Ui.hbox(this);
        onionBox.setBackground(Ui.roundStroke(Ui.SURFACE2, Ui.GOLD_DARK, Ui.dp(this, 1), Ui.dp(this, 26)));
        onionBox.setPadding(Ui.dp(this, 18), Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
        ImageView onionIcon = Ui.icon(this, R.drawable.ic_onion, Ui.GOLD, 20);
        onionBox.addView(onionIcon, new LinearLayout.LayoutParams(Ui.dp(this, 20), Ui.dp(this, 20)));
        EditText et2 = new EditText(this);
        et2.setSingleLine(true);
        et2.setTextColor(Ui.TEXT);
        et2.setHintTextColor(Ui.TEXT3);
        et2.setTextSize(16);
        et2.setBackground(null);
        et2.setHint(getString(R.string.onion_search_hint));
        et2.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        et2.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO) {
                onionSearch(et2.getText().toString());
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams e2p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        e2p.setMarginStart(Ui.dp(this, 10));
        onionBox.addView(et2, e2p);
        ImageView go2 = Ui.icon(this, R.drawable.ic_search, Ui.GOLD, 22);
        go2.setOnClickListener(v -> onionSearch(et2.getText().toString()));
        onionBox.addView(go2, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        LinearLayout.LayoutParams bp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        bp2.setMargins(0, Ui.dp(this, 12), 0, 0);
        root.addView(onionBox, bp2);

        // quick tiles
        LinearLayout tiles = Ui.hbox(this);
        tiles.setGravity(Gravity.CENTER);
        tiles.setPadding(0, Ui.dp(this, 26), 0, 0);
        int[] icons = {R.drawable.ic_onion, R.drawable.ic_vpn, R.drawable.ic_download, R.drawable.ic_bookmark,
                R.drawable.ic_history, R.drawable.ic_console};
        String[] labels = {getString(R.string.tile_onion), getString(R.string.tile_vpn),
                getString(R.string.tile_downloads), getString(R.string.tile_bookmarks),
                getString(R.string.tile_history), getString(R.string.tile_console)};
        View.OnClickListener[] acts = {
                v -> onionSearch(""), v -> openBrowser("badr://tor"), v -> openBrowser("badr://downloads"),
                v -> openBrowser("badr://bookmarks"), v -> openBrowser("badr://history"),
                v -> openBrowser("badr://console")};
        for (int i = 0; i < icons.length; i++) {
            LinearLayout t = Ui.vbox(this);
            t.setGravity(Gravity.CENTER_HORIZONTAL);
            t.setPadding(Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10));
            ImageView iv = Ui.icon(this, icons[i], Ui.GOLD, 24);
            t.addView(iv);
            TextView l = Ui.text(this, labels[i], 11, Ui.TEXT2, false);
            l.setGravity(Gravity.CENTER);
            l.setPadding(0, Ui.dp(this, 6), 0, 0);
            t.addView(l);
            t.setOnClickListener(acts[i]);
            tiles.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(tiles);

        // Tor status card
        LinearLayout card = Ui.card(this);
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
        LinearLayout row = Ui.hbox(this);
        ImageView torIcon = Ui.icon(this, R.drawable.ic_onion, Ui.GOLD, 24);
        row.addView(torIcon, new LinearLayout.LayoutParams(Ui.dp(this, 24), Ui.dp(this, 24)));
        LinearLayout texts = Ui.vbox(this);
        TextView title = Ui.text(this, getString(R.string.tor_title), 16, Ui.TEXT, true);
        texts.addView(title);
        TextView status = Ui.text(this, "", 13, Ui.TEXT2, false);
        status.setPadding(0, Ui.dp(this, 2), 0, 0);
        texts.addView(status);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tlp.setMarginStart(Ui.dp(this, 14));
        row.addView(texts, tlp);
        TextView btn = Ui.pill(this, getString(R.string.open), false, v -> openBrowser("badr://tor"));
        row.addView(btn);
        card.addView(row);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, Ui.dp(this, 26), 0, 0);
        root.addView(card, cp);

        app.tor().addListener((s, pct, detail) -> {
            switch (s) {
                case ON:
                    status.setText(getString(R.string.tor_on));
                    torIcon.setImageTintList(ColorStateList.valueOf(Ui.GOLD));
                    break;
                case STARTING:
                    status.setText(pct >= 0 ? getString(R.string.tor_starting, pct) : getString(R.string.tor_starting_generic));
                    break;
                default:
                    status.setText(getString(R.string.tor_off));
                    torIcon.setImageTintList(ColorStateList.valueOf(Ui.TEXT2));
            }
        });

        // bookmarks
        List<String[]> bookmarks = app.db().bookmarks();
        if (!bookmarks.isEmpty()) {
            root.addView(Ui.sectionTitle(this, getString(R.string.bookmarks_title)));
            LinearLayout list = Ui.card(this);
            for (int i = 0; i < Math.min(6, bookmarks.size()); i++) {
                String[] b = bookmarks.get(i);
                String bookmarkTitle = b[1] == null || b[1].isEmpty() ? Domains.displayHost(b[0]) : b[1];
                list.addView(Ui.row(this, R.drawable.ic_bookmark, bookmarkTitle, Domains.displayHost(b[0]), null,
                        v -> openBrowser(b[0])));
            }
            root.addView(list);
        }

        // history
        List<String[]> history = app.db().history(6);
        if (!history.isEmpty()) {
            root.addView(Ui.sectionTitle(this, getString(R.string.history_title)));
            LinearLayout list = Ui.card(this);
            for (String[] h : history) {
                String historyTitle = h[1] == null || h[1].isEmpty() ? Domains.displayHost(h[0]) : h[1];
                list.addView(Ui.row(this, R.drawable.ic_history, historyTitle, Domains.displayHost(h[0]), null,
                        v -> openBrowser(h[0])));
            }
            root.addView(list);
        }

        setContentView(scroll);
    }

    private void go(String url) {
        if (url == null || url.isEmpty()) return;
        openBrowser(url);
    }

    private void onionSearch(String q) {
        openBrowser("badr://onion-search?q=" + Domains.encode(q == null ? "" : q));
    }

    private void openBrowser(String url) {
        Intent i = new Intent(this, BrowserActivity.class);
        i.putExtra("url", url);
        startActivity(i);
    }
}
