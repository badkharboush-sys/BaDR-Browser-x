package com.badr.browser;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Small helpers to build the dark & gold UI in code (keeps the app free of AppCompat/Material). */
final class Ui {
    static final int BG = 0xFF08080A;
    static final int SURFACE = 0xFF121215;
    static final int SURFACE2 = 0xFF1B1B20;
    static final int SURFACE3 = 0xFF25252B;
    static final int OUTLINE = 0xFF2E2E36;
    static final int GOLD = 0xFFD4AF37;
    static final int GOLD_LIGHT = 0xFFF1D27A;
    static final int GOLD_DARK = 0xFF9C7A22;
    static final int GOLD_SOFT = 0x26D4AF37;
    static final int TEXT = 0xFFF5F1E6;
    static final int TEXT2 = 0xFFA9A396;
    static final int TEXT3 = 0xFF6F6A60;
    static final int RED = 0xFFE5484D;
    static final int GREEN = 0xFF4CC38A;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static GradientDrawable roundStroke(int fill, int stroke, int strokePx, float radiusPx) {
        GradientDrawable g = round(fill, radiusPx);
        g.setStroke(strokePx, stroke);
        return g;
    }

    static GradientDrawable roundTop(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        return g;
    }

    static GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    /** Ripple on top of a background drawable (or borderless when content is null). */
    static Drawable ripple(Drawable content) {
        return new RippleDrawable(ColorStateList.valueOf(0x33D4AF37), content,
                content == null ? null : new ColorDrawable(0xFFFFFFFF));
    }

    static void clickable(View v) {
        v.setClickable(true);
        v.setFocusable(true);
        Drawable bg = v.getBackground();
        v.setBackground(ripple(bg));
    }

    static TextView text(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    static TextView mono(Context c, CharSequence s, float sp, int color) {
        TextView t = text(c, s, sp, color, false);
        t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    static ImageView icon(Context c, int res, int tint, int sizeDp) {
        ImageView iv = new ImageView(c);
        iv.setImageResource(res);
        iv.setImageTintList(ColorStateList.valueOf(tint));
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return iv;
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(round(SURFACE2, dp(c, 18)));
        int p = dp(c, 4);
        l.setPadding(0, p, 0, p);
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams lpMargins(Context c, int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static TextView sectionTitle(Context c, CharSequence s) {
        TextView t = text(c, s, 13, GOLD, true);
        t.setAllCaps(false);
        t.setPadding(dp(c, 6), dp(c, 18), dp(c, 6), dp(c, 8));
        return t;
    }

    static Switch goldSwitch(Context c, boolean checked) {
        Switch s = new Switch(c);
        int[][] states = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(states, new int[]{GOLD_LIGHT, 0xFF8C8A85}));
        s.setTrackTintList(new ColorStateList(states, new int[]{0xCCB08A26, 0xFF3A3A42}));
        s.setChecked(checked);
        s.setShowText(false);
        return s;
    }

    /** A settings/menu row: icon, title, optional subtitle, optional trailing view. */
    static LinearLayout row(Context c, int iconRes, CharSequence title, CharSequence subtitle, View trailing,
                            View.OnClickListener click) {
        LinearLayout r = hbox(c);
        r.setMinimumHeight(dp(c, 58));
        r.setPadding(dp(c, 16), dp(c, 10), dp(c, 14), dp(c, 10));
        if (iconRes != 0) {
            ImageView iv = icon(c, iconRes, GOLD, 22);
            LinearLayout.LayoutParams p = (LinearLayout.LayoutParams) iv.getLayoutParams();
            p.setMarginEnd(dp(c, 16));
            r.addView(iv, p);
        }
        LinearLayout texts = vbox(c);
        TextView t = text(c, title, 16, TEXT, false);
        texts.addView(t);
        if (!TextUtils.isEmpty(subtitle)) {
            TextView st = text(c, subtitle, 13, TEXT2, false);
            st.setPadding(0, dp(c, 2), 0, 0);
            st.setTag("subtitle");
            texts.addView(st);
        }
        r.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (trailing != null) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            p.setMarginStart(dp(c, 10));
            r.addView(trailing, p);
        }
        if (click != null) {
            r.setOnClickListener(click);
            r.setBackground(ripple(null));
        }
        return r;
    }

    static void setSubtitle(View row, CharSequence s) {
        View v = row.findViewWithTag("subtitle");
        if (v instanceof TextView) ((TextView) v).setText(s);
    }

    /** Row whose trailing view is a switch; the whole row toggles it. */
    static LinearLayout switchRow(Context c, int iconRes, CharSequence title, CharSequence subtitle, boolean checked,
                                  final CheckedListener l) {
        final Switch sw = goldSwitch(c, checked);
        LinearLayout r = row(c, iconRes, title, subtitle, sw, v -> sw.toggle());
        sw.setOnCheckedChangeListener((b, isChecked) -> l.onChecked(isChecked));
        return r;
    }

    interface CheckedListener {
        void onChecked(boolean checked);
    }

    static ImageView chevron(Context c) {
        ImageView iv = icon(c, R.drawable.ic_chevron_right, TEXT3, 20);
        return iv;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(0xFF24242A);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.7f)));
        p.setMarginStart(dp(c, 54));
        v.setLayoutParams(p);
        return v;
    }

    static TextView badge(Context c, String s, int bg, int fg) {
        TextView t = text(c, s, 11, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setMinWidth(dp(c, 20));
        t.setPadding(dp(c, 6), dp(c, 1), dp(c, 6), dp(c, 1));
        t.setBackground(round(bg, dp(c, 10)));
        return t;
    }

    static TextView pill(Context c, CharSequence s, boolean primary, View.OnClickListener l) {
        TextView t = text(c, s, 15, primary ? 0xFF15110A : TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(c, 46));
        t.setPadding(dp(c, 18), dp(c, 10), dp(c, 18), dp(c, 10));
        t.setBackground(ripple(primary ? round(GOLD, dp(c, 23)) : roundStroke(SURFACE3, OUTLINE, dp(c, 1), dp(c, 23))));
        t.setOnClickListener(l);
        return t;
    }

    static void toast(Context c, CharSequence s) {
        Toast.makeText(c.getApplicationContext(), s, Toast.LENGTH_SHORT).show();
    }

    /** Bottom sheet built on a plain Dialog. */
    static Dialog sheet(Activity a, View content) {
        return sheet(a, content, true);
    }

    static Dialog sheet(Activity a, View content, boolean scroll) {
        Dialog d = new Dialog(a, R.style.Theme_Badr_Sheet);
        LinearLayout root = vbox(a);
        root.setBackground(roundTop(SURFACE, dp(a, 26)));
        root.setPadding(0, 0, 0, dp(a, 12));
        View handle = new View(a);
        handle.setBackground(round(0xFF3A3A42, dp(a, 3)));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(a, 38), dp(a, 4));
        hp.gravity = Gravity.CENTER_HORIZONTAL;
        hp.setMargins(0, dp(a, 10), 0, dp(a, 6));
        root.addView(handle, hp);
        if (scroll) {
            ScrollView sv = new ScrollView(a);
            sv.setFillViewport(false);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(content, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
            w.setWindowAnimations(android.R.style.Animation_InputMethod);
            w.setBackgroundDrawable(new ColorDrawable(0));
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            int maxH = (int) (a.getResources().getDisplayMetrics().heightPixels * 0.9f);
            root.setMinimumHeight(0);
            content.post(() -> {
                if (root.getHeight() > maxH) w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, maxH);
            });
        }
        d.setCanceledOnTouchOutside(true);
        return d;
    }

    /** Title + optional subtitle header used inside sheets. */
    static LinearLayout sheetHeader(Context c, CharSequence title, CharSequence subtitle) {
        LinearLayout h = vbox(c);
        h.setPadding(dp(c, 20), dp(c, 6), dp(c, 20), dp(c, 10));
        TextView t = text(c, title, 20, TEXT, true);
        h.addView(t);
        if (!TextUtils.isEmpty(subtitle)) {
            TextView s = text(c, subtitle, 13, TEXT2, false);
            s.setPadding(0, dp(c, 4), 0, 0);
            h.addView(s);
        }
        return h;
    }

    static String humanBytes(long b) {
        if (b < 0) return "?";
        if (b < 1024) return b + " B";
        double v = b;
        String[] u = {"KB", "MB", "GB", "TB"};
        int i = -1;
        do {
            v /= 1024;
            i++;
        } while (v >= 1024 && i < u.length - 1);
        return String.format(java.util.Locale.US, v >= 100 ? "%.0f %s" : "%.1f %s", v, u[i]);
    }

    static String compactCount(long n) {
        if (n < 1000) return String.valueOf(n);
        if (n < 1_000_000) return String.format(java.util.Locale.US, n < 10_000 ? "%.1fK" : "%.0fK", n / 1000.0);
        return String.format(java.util.Locale.US, "%.1fM", n / 1_000_000.0);
    }
}
