package com.badr.browser;

import android.content.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.Set;

/**
 * Ad/tracker domain blocklist plus the onion abuse filter.
 *
 * The abuse filter is Ahmia's public list of banned onion hosts (CSAM), distributed as MD5 hashes of the
 * host name. We keep only the first 5 bytes of each hash in a sorted table, so a lookup is a binary search
 * and the whole table is ~300 KB. A match means "do not connect".
 */
final class Blocklist {
    private final Set<String> domains = new HashSet<>();
    private byte[] abuse = new byte[0];
    private int abuseCount;
    private volatile boolean ready;

    private Blocklist() {}

    static Blocklist load(Context c) {
        Blocklist b = new Blocklist();
        b.loadBuiltin(c);
        b.loadAbuse(c);
        b.ready = true;
        return b;
    }

    private void loadBuiltin(Context c) {
        try (InputStream in = c.getAssets().open("filters/builtin.txt");
             BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && line.charAt(0) != '#') domains.add(line);
            }
        } catch (IOException ignored) {
        }
    }

    private void loadAbuse(Context c) {
        try (InputStream in = c.getAssets().open("filters/abuse.bin")) {
            abuse = in.readAllBytes();
            abuseCount = abuse.length / 5;
        } catch (IOException ignored) {
        }
    }

    boolean isReady() {
        return ready;
    }

    int size() {
        return domains.size();
    }

    int abuseSize() {
        return abuseCount;
    }

    /** True when the host (or any parent domain) is a known ad/tracker domain. */
    boolean isBlocked(String host) {
        if (host == null || host.isEmpty()) return false;
        String h = host;
        while (true) {
            if (domains.contains(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0) return false;
            h = h.substring(dot + 1);
            if (h.indexOf('.') < 0) return false;
        }
    }

    /** True when this onion host is on the abuse list. */
    boolean isAbusive(String host) {
        if (host == null || abuseCount == 0) return false;
        byte[] d = md5(host.getBytes(StandardCharsets.UTF_8));
        if (d == null) return false;
        int lo = 0, hi = abuseCount - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            int off = mid * 5;
            int cmp = 0;
            for (int i = 0; i < 5; i++) {
                cmp = (d[i] & 0xFF) - (abuse[off + i] & 0xFF);
                if (cmp != 0) break;
            }
            if (cmp == 0) return true;
            if (cmp < 0) hi = mid - 1;
            else lo = mid + 1;
        }
        return false;
    }

    private static byte[] md5(byte[] in) {
        try {
            return MessageDigest.getInstance("MD5").digest(in);
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    /** First 5 bytes of MD5(host) - used by the off-device unit test. */
    static byte[] abuseKey(String host) {
        try {
            byte[] d = MessageDigest.getInstance("MD5").digest(host.getBytes("UTF-8"));
            byte[] k = new byte[5];
            System.arraycopy(d, 0, k, 0, 5);
            return k;
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            return null;
        }
    }
}
