package com.badr.browser;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * The browser itself: a single WebView with tabs, the omnibox, per-site onion routing, the ad blocker,
 * the download detector, the console capture and the page menu.
 */
public final class BrowserActivity extends Activity implements Sheets.Host {
    private static final String START = "badr://start";

    private BadrApp app;
    private Prefs prefs;
    private Db db;

    private final List<Tab> tabs = new ArrayList<>();
    private int current = -1;

    private LinearLayout root;
    private LinearLayout toolbar;
    private EditText omnibox;
    private ImageView lockIcon;
    private TextView onionBadge;
    private ProgressBar progress;
    private FrameLayout webHost;
    private LinearLayout bottomBar;
    private ImageView torIcon;
    private TextView torLabel;
    private TextView blockedLabel;
    private Dialog sheet;

    private final Set<String> torHosts = new LinkedHashSet<>();
    private boolean proxyReady;
    private int blockedCount;
    private String pendingUrl;
    private boolean findMode;

    private static final class Tab {
        WebView web;
        String url = START;
        String title = "";
        boolean desktop;
        boolean onion;
        boolean adblock = true;
        boolean https = true;
        boolean js = true;
        boolean cookies = true;
        int blocked;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        app = BadrApp.get();
        prefs = app.prefs();
        db = app.db();
        buildUi();
        newTab();
        Intent i = getIntent();
        String start = i == null ? null : i.getStringExtra("url");
        if (start != null && !start.isEmpty()) {
            load(start);
        } else if (i != null && i.getData() != null) {
            load(i.getData().toString());
        } else if (i != null && i.getStringExtra(Intent.EXTRA_TEXT) != null) {
            load(i.getStringExtra(Intent.EXTRA_TEXT));
        }
        app.tor().addListener((s, pct, detail) -> {
            updateTorChip();
            if (s == Tor.State.ON) refreshTorHosts();
        });
        refreshTorHosts();
    }

    // ==========================================================================================
    // UI
    // ==========================================================================================
    private void buildUi() {
        root = Ui.vbox(this);
        root.setBackgroundColor(Ui.BG);
        root.setFitsSystemWindows(true);

        toolbar = Ui.hbox(this);
        toolbar.setBackgroundColor(Ui.BG);
        toolbar.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_mark);
        logo.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34)));
        logo.setOnClickListener(v -> goHome());
        toolbar.addView(logo);

        LinearLayout pill = Ui.hbox(this);
        pill.setBackground(Ui.round(Ui.SURFACE2, Ui.dp(this, 22)));
        pill.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        lockIcon = Ui.icon(this, R.drawable.ic_lock, Ui.GOLD, 16);
        pill.addView(lockIcon, new LinearLayout.LayoutParams(Ui.dp(this, 16), Ui.dp(this, 16)));

        omnibox = new EditText(this);
        omnibox.setSingleLine(true);
        omnibox.setTextColor(Ui.TEXT);
        omnibox.setHintTextColor(Ui.TEXT3);
        omnibox.setTextSize(15);
        omnibox.setBackground(null);
        omnibox.setPadding(0, 0, 0, 0);
        omnibox.setImeOptions(EditorInfo.IME_ACTION_GO);
        omnibox.setInputType(EditorInfo.TYPE_CLASS_TEXT | EditorInfo.TYPE_TEXT_VARIATION_URI);
        omnibox.setHint(getString(R.string.omnibox_hint));
        omnibox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {}
        });
        omnibox.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                submitOmnibox();
                return true;
            }
            return false;
        });
        omnibox.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                omnibox.setText(currentUrl());
                omnibox.selectAll();
            } else {
                omnibox.setText(displayUrl());
            }
        });
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        op.setMarginStart(Ui.dp(this, 8));
        op.setMarginEnd(Ui.dp(this, 8));
        pill.addView(omnibox, op);

        onionBadge = Ui.badge(this, getString(R.string.tag_onion), Ui.GOLD_SOFT, Ui.GOLD_LIGHT);
        onionBadge.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.setMarginStart(Ui.dp(this, 6));
        pill.addView(onionBadge, pp);

        ImageView menu = Ui.icon(this, R.drawable.ic_menu, Ui.TEXT, 24);
        menu.setOnClickListener(v -> openPageMenu());
        pill.addView(menu, new LinearLayout.LayoutParams(Ui.dp(this, 30), Ui.dp(this, 30)));

        LinearLayout.LayoutParams pillP = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        pillP.setMarginStart(Ui.dp(this, 8));
        toolbar.addView(pill, pillP);

        ImageView tabsBtn = Ui.icon(this, R.drawable.ic_tabs, Ui.TEXT, 24);
        tabsBtn.setOnClickListener(v -> openTabs());
        toolbar.addView(tabsBtn, new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34)));

        root.addView(toolbar);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(Ui.GOLD));
        progress.setBackgroundTintList(ColorStateList.valueOf(Ui.SURFACE2));
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 2)));

        webHost = new FrameLayout(this);
        root.addView(webHost, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bottomBar = Ui.hbox(this);
        bottomBar.setBackgroundColor(Ui.BG);
        bottomBar.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10), Ui.dp(this, 10));

        LinearLayout torChip = Ui.hbox(this);
        torChip.setBackground(Ui.round(Ui.SURFACE2, Ui.dp(this, 18)));
        torChip.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        torIcon = Ui.icon(this, R.drawable.ic_onion, Ui.TEXT2, 18);
        torChip.addView(torIcon, new LinearLayout.LayoutParams(Ui.dp(this, 18), Ui.dp(this, 18)));
        torLabel = Ui.text(this, getString(R.string.tor_off), 13, Ui.TEXT2, false);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.setMarginStart(Ui.dp(this, 8));
        torChip.addView(torLabel, tp);
        torChip.setOnClickListener(v -> openTorSettings());
        bottomBar.addView(torChip);

        blockedLabel = Ui.text(this, "", 12, Ui.TEXT3, false);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bp.setMarginStart(Ui.dp(this, 12));
        bottomBar.addView(blockedLabel, bp);

        ImageView shield = Ui.icon(this, R.drawable.ic_shield, Ui.GOLD, 22);
        shield.setOnClickListener(v -> openPageMenu());
        bottomBar.addView(shield, new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34)));

        ImageView settings = Ui.icon(this, R.drawable.ic_settings, Ui.TEXT2, 22);
        settings.setOnClickListener(v -> openSettings());
        bottomBar.addView(settings, new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34)));

        root.addView(bottomBar);
        setContentView(root);
        updateTorChip();
    }

    private void updateTorChip() {
        Tor.State s = app.tor().state();
        int color;
        String label;
        switch (s) {
            case ON:
                color = Ui.GOLD;
                label = getString(R.string.tor_on_chip);
                break;
            case STARTING:
                color = Ui.GOLD_LIGHT;
                label = getString(R.string.tor_starting_chip);
                break;
            default:
                color = Ui.TEXT2;
                label = getString(R.string.tor_off);
        }
        torIcon.setImageTintList(ColorStateList.valueOf(color));
        torLabel.setText(label);
        torLabel.setTextColor(color);
    }

    // ==========================================================================================
    // Tabs
    // ==========================================================================================
    private Tab newTabImpl() {
        Tab t = new Tab();
        t.web = new WebView(this);
        applySettings(t);
        t.web.setWebViewClient(client(t));
        t.web.setDownloadListener(downloadListener(t));
        t.web.setWebChromeClient(chromeClient(t));
        t.web.setOnLongClickListener(v -> true);
        tabs.add(t);
        switchTo(tabs.size() - 1);
        return t;
    }

    private void switchTo(int index) {
        if (index < 0 || index >= tabs.size()) return;
        if (current >= 0 && current < tabs.size()) {
            View old = tabs.get(current).web;
            if (old.getParent() != null) ((ViewGroup) old.getParent()).removeView(old);
        }
        current = index;
        Tab t = tabs.get(current);
        webHost.addView(t.web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        applySettings(t);
        refreshToolbar();
    }

    private void closeTabImpl() {
        if (tabs.size() <= 1) {
            goHome();
            return;
        }
        Tab t = tabs.get(current);
        if (t.web.getParent() != null) ((ViewGroup) t.web.getParent()).removeView(t.web);
        t.web.destroy();
        tabs.remove(current);
        switchTo(Math.max(0, current - 1));
    }

    private Tab tab() {
        return tabs.get(current);
    }

    private String currentUrl() {
        return tab().url;
    }

    private String displayUrl() {
        String u = currentUrl();
        if (START.equals(u)) return "";
        return Domains.displayHost(u);
    }

    private void refreshToolbar() {
        Tab t = tab();
        omnibox.setText(displayUrl());
        boolean onion = Domains.isOnion(Domains.hostOf(t.url));
        onionBadge.setVisibility(onion || t.onion ? View.VISIBLE : View.GONE);
        onionBadge.setText(onion ? getString(R.string.tag_onion) : getString(R.string.tag_onion_site));
        lockIcon.setImageResource(t.url.startsWith("https") ? R.drawable.ic_lock : R.drawable.ic_globe);
        lockIcon.setImageTintList(ColorStateList.valueOf(onion ? Ui.GOLD : Ui.TEXT2));
        blockedLabel.setText(t.blocked > 0 ? getString(R.string.blocked_count, t.blocked) : "");
        updateTorChip();
    }

    // ==========================================================================================
    // WebView setup
    // ==========================================================================================
    private void applySettings(Tab t) {
        WebSettings s = t.web.getSettings();
        Db.Site site = db.site(Domains.siteOfUrl(t.url));
        t.js = site.js && prefs.jsGlobal();
        t.cookies = site.cookies && prefs.cookiesGlobal();
        t.adblock = site.adblock && prefs.adblock();
        t.https = site.https && prefs.httpsOnly();
        t.desktop = site.desktop || prefs.desktopGlobal();
        t.onion = site.onion;

        s.setJavaScriptEnabled(t.js);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSafeBrowsingEnabled(prefs.safeBrowsing());
        s.setUserAgentString(userAgent(t.desktop));
        s.setTextZoom(prefs.textSize());
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, true);
        }
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(t.cookies);
        cm.setAcceptThirdPartyCookies(t.web, t.cookies);
        if (!t.cookies) cm.removeAllCookies(null);
    }

    private String userAgent(boolean desktop) {
        String ua = System.getProperty("http.agent", "");
        if (ua == null || ua.isEmpty()) ua = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";
        if (desktop) {
            ua = ua.replace("Mobile", "").replace("Android 13;", "X11; Linux x86_64;");
            if (!ua.contains("X11")) ua = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";
        }
        return ua;
    }

    private WebViewClient client(final Tab t) {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (!Domains.isHttp(url) && !url.startsWith("badr://") && !url.equals("about:blank")) {
                    Sheets.openExternal(BrowserActivity.this, url);
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                t.url = url;
                t.blocked = 0;
                refreshToolbar();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                t.url = url;
                t.title = view.getTitle();
                if (!prefs.incognito() && Domains.isHttp(url)) db.addHistory(url, t.title);
                refreshToolbar();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showError(t, error.getDescription() == null ? "" : error.getDescription().toString(),
                            request.getUrl().toString());
                }
            }

            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                String host = Domains.hostOf(url);
                if (host == null) return null;

                // 1. Abuse filter: never connect to a banned onion host.
                if (prefs.abuseFilter() && Domains.isOnion(host) && app.blocklist() != null
                        && app.blocklist().isAbusive(host)) {
                    return blocked();
                }
                // 2. Ad / tracker domains.
                if (t.adblock && app.blocklist() != null && app.blocklist().isBlocked(host)) {
                    t.blocked++;
                    if (t == tab()) refreshToolbar();
                    return blocked();
                }
                // 3. HTTPS-only upgrade.
                if (t.https && url.startsWith("http://") && !Domains.isOnion(host) && !Domains.isLocal(host)) {
                    String https = Domains.toHttps(url);
                    if (!https.equals(url)) {
                        view.post(() -> view.loadUrl(https));
                        return blocked();
                    }
                }
                return null;
            }

            private android.webkit.WebResourceResponse blocked() {
                return new android.webkit.WebResourceResponse("text/plain", "UTF-8",
                        204, "No Content", null, new java.io.ByteArrayInputStream(new byte[0]));
            }
        };
    }

    private android.webkit.WebChromeClient chromeClient(final Tab t) {
        return new android.webkit.WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                if (!prefs.consoleEnabled()) return false;
                String level = m.messageLevel() == ConsoleMessage.MessageLevel.ERROR ? "error"
                        : m.messageLevel() == ConsoleMessage.MessageLevel.WARNING ? "warn" : "log";
                db.addConsole(level, m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
                return true;
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                t.title = title;
            }
        };
    }

    private DownloadListener downloadListener(final Tab t) {
        return (url, userAgent, contentDisposition, mime, contentLength) -> {
            String name = Downloads.fileName(url, contentDisposition, mime);
            boolean onion = Domains.isOnion(Domains.hostOf(url)) || t.onion;
            long id = db.addDownload(url, name, onion);
            if (onion) {
                if (!app.tor().isOn()) {
                    app.tor().start();
                    Ui.toast(this, getString(R.string.download_tor_wait));
                }
                Downloader.download(this, id, url, name, true, app.tor().socksPort(), new Downloader.Callback() {
                    @Override public void onProgress(long done, long total) {
                        db.setDownload(id, done, "downloading");
                    }
                    @Override public void onDone(java.io.File f, String n, long size) {
                        db.setDownload(id, size, "done");
                        Ui.toast(BrowserActivity.this, getString(R.string.download_done, n));
                    }
                    @Override public void onError(String message) {
                        db.setDownload(id, -1, "failed");
                        Ui.toast(BrowserActivity.this, message);
                    }
                });
            } else {
                long sysId = Downloads.startSystem(this, url, name);
                if (sysId >= 0) {
                    db.setDownload(id, contentLength, "done");
                    Ui.toast(this, getString(R.string.download_started, name));
                } else {
                    db.setDownload(id, -1, "failed");
                    Ui.toast(this, getString(R.string.download_failed));
                }
            }
        };
    }

    // ==========================================================================================
    // Navigation
    // ==========================================================================================
    private void submitOmnibox() {
        String text = omnibox.getText().toString();
        hideKeyboard();
        if (text == null || text.trim().isEmpty()) return;
        String url = Domains.smartUrl(text, prefs.searchEngine());
        if (url == null) return;
        load(url);
    }

    private void load(String url) {
        if (url == null || url.isEmpty()) return;
        Tab t = tab();
        if (START.equals(url)) {
            t.web.loadUrl("about:blank");
            t.url = START;
            refreshToolbar();
            return;
        }
        if (url.startsWith("badr://")) {
            if (url.startsWith("badr://onion-search")) {
                String q = url.substring("badr://onion-search".length());
                if (q.startsWith("?q=")) q = q.substring(3);
                onionSearch(android.net.Uri.decode(q));
                return;
            }
            return;
        }
        String host = Domains.hostOf(url);
        if (host != null && Domains.isOnion(host)) {
            if (prefs.abuseFilter() && app.blocklist() != null && app.blocklist().isAbusive(host)) {
                showError(t, getString(R.string.abuse_blocked), url);
                return;
            }
            if (!app.tor().isOn() && !app.tor().isStarting()) app.tor().start();
            ensureTorHost(host);
        }
        t.web.loadUrl(url);
    }

    private void showError(Tab t, String message, String url) {
        String html = "<!doctype html><html><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{background:#08080A;color:#F5F1E6;font-family:sans-serif;padding:32px 24px}"
                + "h1{color:#D4AF37;font-size:20px}code{color:#A9A396;word-break:break-all;font-size:12px}"
                + "a{color:#F1D27A}</style></head><body><h1>BaDR</h1><p>" + message + "</p>"
                + "<code>" + url + "</code></body></html>";
        t.web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    private void goHomeImpl() {
        load(START);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && getCurrentFocus() != null) imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
    }

    // ==========================================================================================
    // Tor / proxy
    // ==========================================================================================
    private void ensureTorHost(String host) {
        if (host == null || !Domains.safeForProxyRule(host)) return;
        if (torHosts.add(host)) {
            app.tor().setTorHosts(torHosts);
            refreshProxy();
        }
    }

    private void refreshTorHostsImpl() {
        torHosts.clear();
        for (String s : db.onionSites()) torHosts.add(s);
        for (OnionSearch.Engine e : OnionSearch.ENGINES) torHosts.add(OnionSearch.hostOf(e));
        app.tor().setTorHosts(torHosts);
        refreshProxy();
    }

    private void refreshProxy() {
        if (!app.tor().isOn()) return;
        app.proxy().apply(app.tor().socksPort(), torHosts, () -> proxyReady = true);
    }

    private void openTorSettings() {
        show(Sheets.torSettings(this, this));
    }

    // ==========================================================================================
    // Onion search
    // ==========================================================================================
    private void onionSearch(String query) {
        if (query == null || query.trim().isEmpty()) {
            show(Sheets.onionResults(this, this, "", new ArrayList<>(), ""));
            return;
        }
        if (!app.tor().isOn()) {
            app.tor().start();
            Ui.toast(this, getString(R.string.onion_search_wait));
            return;
        }
        OnionSearch.Engine engine = OnionSearch.engine(prefs.onionEngine());
        Ui.toast(this, getString(R.string.onion_searching, engine.name));
        new Thread(() -> {
            List<OnionSearch.Result> results = OnionSearch.search(engine, query, app.tor().socksPort(), app.blocklist());
            runOnUiThread(() -> show(Sheets.onionResults(this, this, query, results, engine.name)));
        }, "badr-onion-search").start();
    }

    // ==========================================================================================
    // Sheets.Host
    // ==========================================================================================
    private void show(Dialog d) {
        if (sheet != null && sheet.isShowing()) sheet.dismiss();
        sheet = d;
        d.setOnDismissListener(x -> sheet = null);
        d.show();
    }

    private void dismissSheet() {
        if (sheet != null && sheet.isShowing()) sheet.dismiss();
    }

    private void openPageMenu() {
        Tab t = tab();
        show(Sheets.pageMenu(this, this, t.url, t.title, db.isBookmarked(t.url)));
    }

    private void openTabsImpl() {
        List<String[]> list = new ArrayList<>();
        for (Tab t : tabs) list.add(new String[]{t.title, t.url});
        show(Sheets.tabsSheet(this, this, list, current));
    }

    private void openSettingsImpl() {
        show(Sheets.settings(this, this));
    }

    @Override public void reload() { dismissSheet(); tab().web.reload(); }
    @Override public void goHome() { dismissSheet(); goHomeImpl(); }
    @Override public void setDesktop(boolean on) {
        dismissSheet();
        Db.Site s = db.site(Domains.siteOfUrl(currentUrl()));
        s.desktop = on;
        db.putSite(Domains.siteOfUrl(currentUrl()), s);
        applySettings(tab());
        tab().web.reload();
    }
    @Override public void setTextSize(int pct) {
        dismissSheet();
        prefs.textSize(pct);
        applySettings(tab());
    }
    @Override public void setJs(boolean on) {
        Db.Site s = db.site(Domains.siteOfUrl(currentUrl()));
        s.js = on;
        db.putSite(Domains.siteOfUrl(currentUrl()), s);
        applySettings(tab());
    }
    @Override public void setCookies(boolean on) {
        Db.Site s = db.site(Domains.siteOfUrl(currentUrl()));
        s.cookies = on;
        db.putSite(Domains.siteOfUrl(currentUrl()), s);
        applySettings(tab());
    }
    @Override public void setAdblock(boolean on) {
        Db.Site s = db.site(Domains.siteOfUrl(currentUrl()));
        s.adblock = on;
        db.putSite(Domains.siteOfUrl(currentUrl()), s);
        applySettings(tab());
    }
    @Override public void setHttpsOnly(boolean on) {
        Db.Site s = db.site(Domains.siteOfUrl(currentUrl()));
        s.https = on;
        db.putSite(Domains.siteOfUrl(currentUrl()), s);
        applySettings(tab());
    }
    @Override public void setOnion(boolean on) {
        String site = Domains.siteOfUrl(currentUrl());
        Db.Site s = db.site(site);
        s.onion = on;
        db.putSite(site, s);
        if (on) {
            if (!app.tor().isOn() && !app.tor().isStarting()) app.tor().start();
            ensureTorHost(site);
            Ui.toast(this, getString(R.string.onion_enabled_toast));
        } else {
            torHosts.remove(site);
            app.tor().setTorHosts(torHosts);
            refreshProxy();
            Ui.toast(this, getString(R.string.onion_disabled_toast));
        }
        refreshToolbar();
    }
    @Override public void clearSiteData() {
        dismissSheet();
        CookieManager.getInstance().removeAllCookies(null);
        tab().web.clearCache(true);
        tab().web.clearHistory();
        Ui.toast(this, getString(R.string.cleared));
    }
    @Override public void newIdentity() { app.tor().newIdentity(); }
    @Override public void openConsole() { dismissSheet(); show(Sheets.console(this, this)); }
    @Override public void openDownloads() { dismissSheet(); show(Sheets.downloads(this, this)); }
    @Override public void openBookmarks() { dismissSheet(); show(Sheets.listSheet(this, this, true)); }
    @Override public void openHistory() { dismissSheet(); show(Sheets.listSheet(this, this, false)); }
    @Override public void openTabs() { dismissSheet(); openTabsImpl(); }
    @Override public void openSettings() { dismissSheet(); openSettingsImpl(); }
    @Override public void openOnionSearch() { dismissSheet(); onionSearch(""); }
    @Override public void copyLink() { dismissSheet(); Sheets.copy(this, currentUrl()); }
    @Override public void findInPage() {
        dismissSheet();
        findMode = true;
        omnibox.setText("");
        omnibox.setHint(getString(R.string.find_hint));
        omnibox.requestFocus();
        Ui.toast(this, getString(R.string.find_hint));
    }
    @Override public void addToHome() {
        dismissSheet();
        Tab t = tab();
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(t.url));
        try {
            startActivity(i);
            Ui.toast(this, getString(R.string.add_home_toast));
        } catch (Exception e) {
            Ui.toast(this, getString(R.string.add_home_fail));
        }
    }
    @Override public void openInOther() {
        dismissSheet();
        Sheets.openExternal(this, currentUrl());
    }
    @Override public void share() { dismissSheet(); Sheets.share(this, currentUrl(), tab().title); }
    @Override public void refreshTorHosts() { refreshTorHostsImpl(); }
    @Override public void restartTor() {
        dismissSheet();
        app.tor().applyConfigAndRestart();
        Ui.toast(this, getString(R.string.tor_restarting));
    }
    @Override public void openUrl(String url) { dismissSheet(); load(url); }
    @Override public void closeTab() { dismissSheet(); closeTabImpl(); }
    @Override public void newTab() { dismissSheet(); newTabImpl(); }

    // ==========================================================================================
    @Override
    public void onBackPressed() {
        if (sheet != null && sheet.isShowing()) {
            sheet.dismiss();
            return;
        }
        Tab t = tab();
        if (t.web.canGoBack()) {
            t.web.goBack();
        } else if (tabs.size() > 1) {
            closeTab();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (prefs.clearOnExit()) {
            CookieManager.getInstance().removeAllCookies(null);
            for (Tab t : tabs) {
                t.web.clearCache(true);
                t.web.clearHistory();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        for (Tab t : tabs) {
            try {
                t.web.destroy();
            } catch (Exception ignored) {
            }
        }
        tabs.clear();
    }
}
