package com.badr.browser;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Onion search over Tor. Three engines are supported (Ahmia, TORCH, Excavator); results are fetched over
 * the Tor SOCKS port, parsed, de-duplicated, and filtered against the abuse list before being shown.
 * The Ahmia "token" in its search URL rotates, so it is fetched from the engine home page first.
 */
final class OnionSearch {
    static final class Engine {
        final String id, name, home, searchUrl, tokenUrl;
        final boolean needsToken;

        Engine(String id, String name, String home, String searchUrl, String tokenUrl, boolean needsToken) {
            this.id = id;
            this.name = name;
            this.home = home;
            this.searchUrl = searchUrl;
            this.tokenUrl = tokenUrl;
            this.needsToken = needsToken;
        }
    }

    static final class Result {
        String url, title, snippet, engine;
    }

    static final Engine[] ENGINES = {
            new Engine("ahmia", "Ahmia",
                    "http://juhanurmihxlp77nkq76byazcldy2hlmovfu2epvl5ankdibsot4csyd.onion/",
                    "http://juhanurmihxlp77nkq76byazcldy2hlmovfu2epvl5ankdibsot4csyd.onion/search/?q=%s",
                    "http://juhanurmihxlp77nkq76byazcldy2hlmovfu2epvl5ankdibsot4csyd.onion/", true),
            new Engine("torch", "TORCH",
                    "http://xmh57jrknzkhv6y3ls3ubitzfqnkrwxhopf5aygthi7d6rplyvk3noyd.onion/",
                    "http://xmh57jrknzkhv6y3ls3ubitzfqnkrwxhopf5aygthi7d6rplyvk3noyd.onion/cgi-bin/omega/omega?P=%s",
                    null, false),
            new Engine("excavator", "Excavator",
                    "http://2fd6cemt4gmccflhm6imvdfvli3nf7zn6rfrwpsy7uhxrgbypvwf5fad.onion/",
                    "http://2fd6cemt4gmccflhm6imvdfvli3nf7zn6rfrwpsy7uhxrgbypvwf5fad.onion/search?query=%s",
                    null, false),
    };

    private static final Pattern ANCHOR = Pattern.compile(
            "<a\\s[^>]*?href=[\"'](https?://[a-z2-7]{16,56}\\.onion[^\"'\\s<>]*)[\"'][^>]*>(.*?)</a>",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern TAG = Pattern.compile("<[^>]+>");
    private static final Pattern TOKEN = Pattern.compile(
            "type=[\"']hidden[\"'][^>]*?name=[\"']([a-z0-9]+)[\"'][^>]*?value=[\"']([a-z0-9]+)[\"']",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern TOKEN2 = Pattern.compile(
            "name=[\"']([a-z0-9]+)[\"'][^>]*?value=[\"']([a-z0-9]+)[\"']", Pattern.CASE_INSENSITIVE);

    private OnionSearch() {}

    static Engine engine(String id) {
        for (Engine e : ENGINES) if (e.id.equals(id)) return e;
        return ENGINES[0];
    }

    static String fetchToken(Engine e, int socksPort) {
        String html = Tor.TorHttp.get(e.tokenUrl, socksPort, 20000);
        if (html == null) return null;
        Matcher m = TOKEN.matcher(html);
        if (m.find()) return m.group(1) + "=" + m.group(2);
        m = TOKEN2.matcher(html);
        if (m.find()) return m.group(1) + "=" + m.group(2);
        return null;
    }

    static List<Result> search(Engine e, String query, int socksPort, Blocklist blocklist) {
        String url = e.searchUrl.replace("%s", Domains.encode(query));
        if (e.needsToken) {
            String tok = fetchToken(e, socksPort);
            if (tok != null) url += "&" + tok;
        }
        String html = Tor.TorHttp.get(url, socksPort, 45000);
        List<Result> out = new ArrayList<>();
        if (html == null || html.isEmpty()) return out;
        Map<String, Result> seen = new LinkedHashMap<>();
        Matcher m = ANCHOR.matcher(html);
        while (m.find()) {
            String href = unescape(m.group(1));
            String text = clean(m.group(2));
            String host = Domains.hostOf(href);
            if (host == null || !Domains.isOnion(host)) continue;
            if (host.equals(Domains.hostOf(e.home))) continue; // engine's own links
            if (blocklist != null && blocklist.isAbusive(host)) continue;
            if (text.isEmpty()) text = host;
            if (text.length() > 140) text = text.substring(0, 140);
            Result r = new Result();
            r.url = href;
            r.title = text;
            r.snippet = "";
            r.engine = e.name;
            seen.putIfAbsent(href, r);
        }
        // Attach snippets: text following each anchor up to the next anchor.
        List<Result> list = new ArrayList<>(seen.values());
        Matcher m2 = ANCHOR.matcher(html);
        int idx = 0;
        int lastEnd = 0;
        while (m2.find()) {
            String href = unescape(m2.group(1));
            Result r = seen.get(href);
            if (r != null && r.snippet.isEmpty()) {
                int from = m2.end();
                int to = html.indexOf("<a ", from);
                if (to < 0) to = Math.min(html.length(), from + 600);
                String snip = clean(html.substring(from, Math.min(to, from + 600)));
                if (snip.length() > 220) snip = snip.substring(0, 220);
                r.snippet = snip;
            }
            idx++;
            if (idx > 400) break;
        }
        out.addAll(list);
        return out;
    }

    static String clean(String s) {
        if (s == null) return "";
        String t = TAG.matcher(s).replaceAll(" ");
        t = unescape(t);
        t = t.replaceAll("\\s+", " ").trim();
        return t;
    }

    static String unescape(String s) {
        if (s == null) return "";
        return s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ");
    }

    static String hostOf(Engine e) {
        return Domains.hostOf(e.home);
    }
}
