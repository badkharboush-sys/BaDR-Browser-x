package com.badr.browser;

import android.content.Context;
import android.content.SharedPreferences;

/** Global settings. */
final class Prefs {
    static final String SEARCH_GOOGLE = "https://www.google.com/search?q=%s";
    static final String SEARCH_DDG = "https://duckduckgo.com/?q=%s";
    static final String SEARCH_BRAVE = "https://search.brave.com/search?q=%s";
    static final String SEARCH_STARTPAGE = "https://www.startpage.com/sp/search?query=%s";
    static final String SEARCH_QWANT = "https://www.qwant.com/?q=%s&t=web";

    private final SharedPreferences p;

    Prefs(Context c) {
        p = c.getSharedPreferences("badr_prefs", Context.MODE_PRIVATE);
    }

    private void put(String k, boolean v) { p.edit().putBoolean(k, v).apply(); }
    private void put(String k, int v) { p.edit().putInt(k, v).apply(); }
    private void put(String k, String v) { p.edit().putString(k, v).apply(); }

    boolean adblock() { return p.getBoolean("adblock", true); }
    void adblock(boolean v) { put("adblock", v); }

    boolean httpsOnly() { return p.getBoolean("https_only", true); }
    void httpsOnly(boolean v) { put("https_only", v); }

    boolean jsGlobal() { return p.getBoolean("js_global", true); }
    void jsGlobal(boolean v) { put("js_global", v); }

    boolean cookiesGlobal() { return p.getBoolean("cookies_global", true); }
    void cookiesGlobal(boolean v) { put("cookies_global", v); }

    boolean clearOnExit() { return p.getBoolean("clear_on_exit", false); }
    void clearOnExit(boolean v) { put("clear_on_exit", v); }

    boolean incognito() { return p.getBoolean("incognito", false); }
    void incognito(boolean v) { put("incognito", v); }

    boolean desktopGlobal() { return p.getBoolean("desktop_global", false); }
    void desktopGlobal(boolean v) { put("desktop_global", v); }

    boolean safeBrowsing() { return p.getBoolean("safe_browsing", true); }
    void safeBrowsing(boolean v) { put("safe_browsing", v); }

    boolean darkWeb() { return p.getBoolean("dark_web", true); }
    void darkWeb(boolean v) { put("dark_web", v); }

    boolean abuseFilter() { return p.getBoolean("abuse_filter", true); }
    void abuseFilter(boolean v) { put("abuse_filter", v); }

    boolean consoleEnabled() { return p.getBoolean("console_enabled", true); }
    void consoleEnabled(boolean v) { put("console_enabled", v); }

    int textSize() { return p.getInt("text_size", 100); }
    void textSize(int v) { put("text_size", v); }

    String searchEngine() { return p.getString("search_engine", SEARCH_GOOGLE); }
    void searchEngine(String v) { put("search_engine", v); }

    /** Tor exit country code (lower case) or "auto". */
    String exitCountry() { return p.getString("exit_country", "auto"); }
    void exitCountry(String v) { put("exit_country", v); }

    /** 0 = auto, 1 = socks, 2 = bridges. */
    int torTransport() { return p.getInt("tor_transport", 0); }
    void torTransport(int v) { put("tor_transport", v); }

    String obfs4Bridge() { return p.getString("obfs4_bridge", ""); }
    void obfs4Bridge(String v) { put("obfs4_bridge", v); }

    /** Onion search engine id: ahmia | torch | excavator. */
    String onionEngine() { return p.getString("onion_engine", "ahmia"); }
    void onionEngine(String v) { put("onion_engine", v); }

    boolean firstRun() { return p.getBoolean("first_run", true); }
    void firstRun(boolean v) { put("first_run", v); }
}
