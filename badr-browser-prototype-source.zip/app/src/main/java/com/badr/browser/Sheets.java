package com.badr.browser;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * All bottom sheets: the page menu (from the reference screenshot), site settings, Tor/VPN settings,
 * downloads, console (web-dev), bookmarks, history, tabs and the onion search UI.
 */
final class Sheets {
    interface Host {
        void reload();

        void goHome();

        void setDesktop(boolean on);

        void setTextSize(int pct);

        void setJs(boolean on);

        void setCookies(boolean on);

        void setAdblock(boolean on);

        void setHttpsOnly(boolean on);

        void setOnion(boolean on);

        void clearSiteData();

        void newIdentity();

        void openConsole();

        void openDownloads();

        void openBookmarks();

        void openHistory();

        void openTabs();

        void openSettings();

        void openOnionSearch();

        void copyLink();

        void findInPage();

        void addToHome();

        void openInOther();

        void share();

        void refreshTorHosts();

        void restartTor();

        void openUrl(String url);

        void closeTab();

        void newTab();
    }

    private Sheets() {}

    // ------------------------------------------------------------------------------------------
    // Page menu (mirrors the reference screenshot, dark & gold)
    // ------------------------------------------------------------------------------------------
    static Dialog pageMenu(Activity a, Host h, String url, String title, boolean bookmarked) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 14), 0, Ui.dp(a, 14), Ui.dp(a, 10));

        // URL pill
        LinearLayout pill = Ui.hbox(a);
        pill.setBackground(Ui.round(Ui.SURFACE3, Ui.dp(a, 18)));
        pill.setPadding(Ui.dp(a, 16), Ui.dp(a, 12), Ui.dp(a, 16), Ui.dp(a, 12));
        ImageView lock = Ui.icon(a, R.drawable.ic_lock, Ui.GOLD, 18);
        pill.addView(lock, new LinearLayout.LayoutParams(Ui.dp(a, 18), Ui.dp(a, 18)));
        TextView u = Ui.text(a, Domains.displayHost(url), 16, Ui.TEXT, false);
        u.setSingleLine(true);
        u.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams up = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        up.setMarginStart(Ui.dp(a, 10));
        pill.addView(u, up);
        boolean onion = Domains.isOnion(Domains.hostOf(url));
        TextView tag = Ui.badge(a, onion ? a.getString(R.string.tag_onion) : a.getString(R.string.tag_clearnet),
                onion ? Ui.GOLD_SOFT : Ui.SURFACE2, onion ? Ui.GOLD_LIGHT : Ui.TEXT2);
        pill.addView(tag);
        ImageView pencil = Ui.icon(a, R.drawable.ic_edit, Ui.TEXT2, 18);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(a, 18), Ui.dp(a, 18));
        pp.setMarginStart(Ui.dp(a, 10));
        pill.addView(pencil, pp);
        pill.setOnClickListener(v -> {
            h.copyLink();
        });
        root.addView(pill);

        // nav row
        LinearLayout nav = Ui.hbox(a);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 4));
        int[] navIcons = {R.drawable.ic_back, R.drawable.ic_forward, R.drawable.ic_reload,
                bookmarked ? R.drawable.ic_star_filled : R.drawable.ic_star, R.drawable.ic_share};
        View.OnClickListener[] navActs = {
                v -> h.reload(), v -> h.reload(), v -> h.reload(), v -> h.openBookmarks(), v -> h.share()};
        for (int i = 0; i < navIcons.length; i++) {
            ImageView iv = Ui.icon(a, navIcons[i], Ui.TEXT, 26);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(a, 52), Ui.dp(a, 52));
            p.setMarginStart(Ui.dp(a, 8));
            p.setMarginEnd(Ui.dp(a, 8));
            iv.setOnClickListener(navActs[i]);
            nav.addView(iv, p);
        }
        root.addView(nav);

        // tiles
        LinearLayout tiles = Ui.hbox(a);
        tiles.setGravity(Gravity.CENTER);
        tiles.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 4));
        int[] tileIcons = {R.drawable.ic_copy, R.drawable.ic_find, R.drawable.ic_text_size,
                R.drawable.ic_desktop, R.drawable.ic_add_home, R.drawable.ic_external};
        String[] tileLabels = {a.getString(R.string.tile_copy), a.getString(R.string.tile_find),
                a.getString(R.string.tile_text), a.getString(R.string.tile_desktop),
                a.getString(R.string.tile_home), a.getString(R.string.tile_other)};
        View.OnClickListener[] tileActs = {v -> h.copyLink(), v -> h.findInPage(), v -> textSizeSheet(a, h),
                v -> h.setDesktop(!hDesktop(a)), v -> h.addToHome(), v -> h.openInOther()};
        for (int i = 0; i < tileIcons.length; i++) {
            LinearLayout t = Ui.vbox(a);
            t.setGravity(Gravity.CENTER_HORIZONTAL);
            t.setPadding(Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 4), Ui.dp(a, 8));
            ImageView iv = Ui.icon(a, tileIcons[i], Ui.GOLD, 24);
            t.addView(iv);
            TextView l = Ui.text(a, tileLabels[i], 11, Ui.TEXT2, false);
            l.setGravity(Gravity.CENTER);
            l.setPadding(0, Ui.dp(a, 6), 0, 0);
            t.addView(l);
            t.setOnClickListener(tileActs[i]);
            tiles.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(tiles);

        // privacy section
        root.addView(Ui.sectionTitle(a, a.getString(R.string.section_privacy)));
        LinearLayout card = Ui.card(a);
        Db.Site site = BadrApp.get().db().site(Domains.siteOfUrl(url));
        LinearLayout onionRow = Ui.switchRow(a, R.drawable.ic_onion, a.getString(R.string.onion_routing),
                a.getString(R.string.onion_routing_sub), site.onion, on -> {
                    h.setOnion(on);
                });
        card.addView(onionRow);
        card.addView(Ui.divider(a));
        card.addView(Ui.row(a, R.drawable.ic_settings, a.getString(R.string.site_settings),
                siteSummary(a, site), Ui.chevron(a), v -> siteSettingsSheet(a, h, url)));
        card.addView(Ui.divider(a));
        card.addView(Ui.row(a, R.drawable.ic_cookie, a.getString(R.string.cookies_title),
                a.getString(R.string.cookies_sub), Ui.chevron(a), v -> siteSettingsSheet(a, h, url)));
        root.addView(card);

        // console row
        LinearLayout console = Ui.row(a, R.drawable.ic_console, a.getString(R.string.console_title),
                a.getString(R.string.console_sub), Ui.badge(a, String.valueOf(BadrApp.get().db().consoleCount()),
                        Ui.RED, 0xFFFFFFFF), v -> h.openConsole());
        root.addView(console);

        return Ui.sheet(a, root);
    }

    private static boolean hDesktop(Activity a) {
        return BadrApp.get().prefs().desktopGlobal();
    }

    private static String siteSummary(Context c, Db.Site s) {
        List<String> parts = new ArrayList<>();
        parts.add(c.getString(s.js ? R.string.site_js_on : R.string.site_js_off));
        parts.add(c.getString(s.cookies ? R.string.site_cookies_on : R.string.site_cookies_off));
        parts.add(c.getString(s.adblock ? R.string.site_adblock_on : R.string.site_adblock_off));
        return TextUtils.join(" · ", parts);
    }

    // ------------------------------------------------------------------------------------------
    static Dialog textSizeSheet(Activity a, Host h) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.tile_text), a.getString(R.string.text_size_sub)));
        int cur = BadrApp.get().prefs().textSize();
        int[] sizes = {80, 90, 100, 110, 125, 150, 175, 200};
        for (int s : sizes) {
            LinearLayout r = Ui.row(a, s == cur ? R.drawable.ic_check : 0,
                    s + "%", s == cur ? a.getString(R.string.current) : null, null,
                    v -> h.setTextSize(s));
            root.addView(r);
        }
        return Ui.sheet(a, root);
    }

    static Dialog siteSettingsSheet(Activity a, Host h, String url) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, Domains.displayHost(url), a.getString(R.string.site_settings)));
        Db.Site site = BadrApp.get().db().site(Domains.siteOfUrl(url));
        root.addView(Ui.switchRow(a, R.drawable.ic_onion, a.getString(R.string.onion_routing),
                a.getString(R.string.onion_routing_sub), site.onion, on -> h.setOnion(on)));
        root.addView(Ui.switchRow(a, R.drawable.ic_code, a.getString(R.string.site_js),
                a.getString(R.string.site_js_sub), site.js, on -> h.setJs(on)));
        root.addView(Ui.switchRow(a, R.drawable.ic_cookie, a.getString(R.string.site_cookies),
                a.getString(R.string.site_cookies_sub), site.cookies, on -> h.setCookies(on)));
        root.addView(Ui.switchRow(a, R.drawable.ic_shield, a.getString(R.string.site_adblock),
                a.getString(R.string.site_adblock_sub), site.adblock, on -> h.setAdblock(on)));
        root.addView(Ui.switchRow(a, R.drawable.ic_lock, a.getString(R.string.site_https),
                a.getString(R.string.site_https_sub), site.https, on -> h.setHttpsOnly(on)));
        root.addView(Ui.switchRow(a, R.drawable.ic_desktop, a.getString(R.string.tile_desktop),
                a.getString(R.string.site_desktop_sub), site.desktop, on -> h.setDesktop(on)));
        TextView clear = Ui.pill(a, a.getString(R.string.clear_site_data), false, v -> h.clearSiteData());
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, Ui.dp(a, 14), 0, Ui.dp(a, 6));
        root.addView(clear, cp);
        return Ui.sheet(a, root);
    }

    // ------------------------------------------------------------------------------------------
    // Tor / VPN settings
    // ------------------------------------------------------------------------------------------
    static Dialog torSettings(Activity a, Host h) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.tor_title), a.getString(R.string.tor_sub)));

        Tor tor = BadrApp.get().tor();
        TextView status = Ui.text(a, "", 14, Ui.GOLD_LIGHT, true);
        status.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 8));
        root.addView(status);
        ProgressBar bar = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(Ui.GOLD));
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.GOLD));
        bar.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Ui.SURFACE3));
        bar.setVisibility(View.GONE);
        root.addView(bar);
        TextView ip = Ui.text(a, "", 13, Ui.TEXT2, false);
        ip.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 4));
        root.addView(ip);

        Tor.Listener listener = (s, pct, detail) -> {
            String txt;
            switch (s) {
                case ON:
                    txt = a.getString(R.string.tor_on);
                    bar.setVisibility(View.GONE);
                    break;
                case STARTING:
                    txt = pct >= 0 ? a.getString(R.string.tor_starting, pct) : a.getString(R.string.tor_starting_generic);
                    bar.setVisibility(View.VISIBLE);
                    bar.setProgress(Math.max(0, pct));
                    break;
                case STOPPING:
                    txt = a.getString(R.string.tor_stopping);
                    break;
                default:
                    txt = a.getString(R.string.tor_off);
                    bar.setVisibility(View.GONE);
            }
            status.setText(txt);
            ip.setText(tor.exitIp().isEmpty() ? "" : a.getString(R.string.tor_exit_ip, tor.exitIp()));
        };
        tor.addListener(listener);

        LinearLayout card = Ui.card(a);
        card.addView(Ui.switchRow(a, R.drawable.ic_onion, a.getString(R.string.tor_enable),
                a.getString(R.string.tor_enable_sub), tor.isOn() || tor.isStarting(), on -> {
                    if (on) tor.start();
                    else tor.stop();
                }));
        card.addView(Ui.divider(a));
        card.addView(Ui.row(a, R.drawable.ic_bolt, a.getString(R.string.tor_new_identity),
                a.getString(R.string.tor_new_identity_sub), null, v -> {
                    tor.newIdentity();
                    Ui.toast(a, a.getString(R.string.tor_new_identity_toast));
                }));
        card.addView(Ui.divider(a));
        card.addView(Ui.row(a, R.drawable.ic_pin, a.getString(R.string.tor_country),
                countryLabel(a, BadrApp.get().prefs().exitCountry()), Ui.chevron(a), v -> countrySheet(a, h)));
        card.addView(Ui.divider(a));
        card.addView(Ui.row(a, R.drawable.ic_vpn, a.getString(R.string.tor_transport),
                transportLabel(a, BadrApp.get().prefs().torTransport()), Ui.chevron(a), v -> transportSheet(a, h)));
        root.addView(card);

        root.addView(Ui.sectionTitle(a, a.getString(R.string.tor_sites_title)));
        LinearLayout sites = Ui.vbox(a);
        List<String> onion = BadrApp.get().db().onionSites();
        if (onion.isEmpty()) {
            TextView none = Ui.text(a, a.getString(R.string.tor_sites_none), 14, Ui.TEXT2, false);
            none.setPadding(Ui.dp(a, 6), Ui.dp(a, 4), Ui.dp(a, 6), Ui.dp(a, 10));
            sites.addView(none);
        } else {
            for (String s : onion) {
                sites.addView(Ui.row(a, R.drawable.ic_onion, s, a.getString(R.string.tor_site_on), null, null));
            }
        }
        root.addView(sites);
        return Ui.sheet(a, root);
    }

    private static String countryLabel(Context c, String code) {
        if (code == null || code.equals("auto")) return c.getString(R.string.tor_country_auto);
        return code.toUpperCase(java.util.Locale.ROOT);
    }

    private static String transportLabel(Context c, int t) {
        switch (t) {
            case 1:
                return c.getString(R.string.transport_socks);
            case 2:
                return c.getString(R.string.transport_bridges);
            default:
                return c.getString(R.string.transport_auto);
        }
    }

    static Dialog countrySheet(Activity a, Host h) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.tor_country), a.getString(R.string.tor_country_sub)));
        String[] codes = {"auto", "us", "nl", "de", "se", "at", "fr", "no", "ch", "is", "gb", "ca", "au", "jp", "sg", "za", "ro", "fi", "dk", "pl"};
        String cur = BadrApp.get().prefs().exitCountry();
        for (String code : codes) {
            LinearLayout r = Ui.row(a, code.equals(cur) ? R.drawable.ic_check : 0,
                    countryLabel(a, code), null, null, v -> {
                        BadrApp.get().prefs().exitCountry(code);
                        h.restartTor();
                    });
            root.addView(r);
        }
        return Ui.sheet(a, root);
    }

    static Dialog transportSheet(Activity a, Host h) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.tor_transport), a.getString(R.string.transport_sub)));
        int cur = BadrApp.get().prefs().torTransport();
        int[] modes = {0, 1, 2};
        for (int m : modes) {
            LinearLayout r = Ui.row(a, m == cur ? R.drawable.ic_check : 0,
                    transportLabel(a, m), transportSub(a, m), null, v -> {
                        BadrApp.get().prefs().torTransport(m);
                        h.restartTor();
                    });
            root.addView(r);
        }
        root.addView(Ui.row(a, R.drawable.ic_edit, a.getString(R.string.transport_bridges_edit),
                a.getString(R.string.transport_bridges_edit_sub), Ui.chevron(a), v -> bridgeSheet(a, h)));
        return Ui.sheet(a, root);
    }

    private static String transportSub(Context c, int m) {
        switch (m) {
            case 1:
                return c.getString(R.string.transport_socks_sub);
            case 2:
                return c.getString(R.string.transport_bridges_sub);
            default:
                return c.getString(R.string.transport_auto_sub);
        }
    }

    static Dialog bridgeSheet(Activity a, Host h) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.transport_bridges_edit),
                a.getString(R.string.transport_bridges_edit_sub)));
        EditText et = new EditText(a);
        et.setText(BadrApp.get().prefs().obfs4Bridge());
        et.setHint("obfs4 1.2.3.4:443 ...");
        et.setTextColor(Ui.TEXT);
        et.setHintTextColor(Ui.TEXT3);
        et.setTextSize(13);
        et.setTypeface(Typeface.MONOSPACE);
        et.setMinLines(4);
        et.setGravity(Gravity.TOP);
        et.setBackground(Ui.round(Ui.SURFACE3, Ui.dp(a, 12)));
        et.setPadding(Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12));
        root.addView(et);
        TextView save = Ui.pill(a, a.getString(R.string.save), true, v -> {
            BadrApp.get().prefs().obfs4Bridge(et.getText().toString());
            h.restartTor();
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, Ui.dp(a, 12), 0, Ui.dp(a, 6));
        root.addView(save, p);
        return Ui.sheet(a, root);
    }

    // ------------------------------------------------------------------------------------------
    // Downloads
    // ------------------------------------------------------------------------------------------
    static Dialog downloads(Activity a, Host h) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.downloads_title), a.getString(R.string.downloads_sub)));
        List<String[]> rows = BadrApp.get().db().downloads();
        if (rows.isEmpty()) {
            TextView none = Ui.text(a, a.getString(R.string.downloads_none), 14, Ui.TEXT2, false);
            none.setPadding(Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 12));
            root.addView(none);
        } else {
            for (String[] r : rows) {
                String name = r[2];
                String status = r[4];
                String sub = status.equals("done") ? Ui.humanBytes(Long.parseLong(r[3]))
                        : status.equals("failed") ? a.getString(R.string.download_failed)
                        : a.getString(R.string.download_running);
                if (r[6].equals("1")) sub += " · " + a.getString(R.string.tag_onion);
                root.addView(Ui.row(a, R.drawable.ic_download, name, sub, Ui.chevron(a), v -> h.openDownloads()));
            }
        }
        return Ui.sheet(a, root);
    }

    // ------------------------------------------------------------------------------------------
    // Console (web dev)
    // ------------------------------------------------------------------------------------------
    static Dialog console(Activity a, Host h) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        LinearLayout head = Ui.hbox(a);
        LinearLayout titles = Ui.vbox(a);
        titles.addView(Ui.text(a, a.getString(R.string.console_title), 20, Ui.TEXT, true));
        titles.addView(Ui.text(a, a.getString(R.string.console_sub), 13, Ui.TEXT2, false));
        head.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView clear = Ui.pill(a, a.getString(R.string.clear), false, v -> {
            BadrApp.get().db().clearConsole();
        });
        head.addView(clear);
        root.addView(head);

        LinearLayout list = Ui.vbox(a);
        List<String[]> rows = BadrApp.get().db().console(200);
        if (rows.isEmpty()) {
            TextView none = Ui.text(a, a.getString(R.string.console_empty), 14, Ui.TEXT2, false);
            none.setPadding(Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 12));
            list.addView(none);
        } else {
            for (String[] r : rows) {
                int color = r[0].equals("error") ? Ui.RED : r[0].equals("warn") ? Ui.GOLD_LIGHT : Ui.TEXT2;
                TextView t = Ui.mono(a, r[1], 12, color);
                t.setPadding(Ui.dp(a, 6), Ui.dp(a, 3), Ui.dp(a, 6), Ui.dp(a, 3));
                t.setTextIsSelectable(true);
                list.addView(t);
            }
        }
        root.addView(list);
        return Ui.sheet(a, root);
    }

    // ------------------------------------------------------------------------------------------
    // Bookmarks / history
    // ------------------------------------------------------------------------------------------
    static Dialog listSheet(Activity a, Host h, boolean bookmarks) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(bookmarks ? R.string.bookmarks_title : R.string.history_title),
                a.getString(bookmarks ? R.string.bookmarks_sub : R.string.history_sub)));
        List<String[]> rows = bookmarks ? BadrApp.get().db().bookmarks() : BadrApp.get().db().history(200);
        if (rows.isEmpty()) {
            TextView none = Ui.text(a, a.getString(R.string.list_empty), 14, Ui.TEXT2, false);
            none.setPadding(Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 12));
            root.addView(none);
        } else {
            for (String[] r : rows) {
                String url = r[0];
                String title = r[1] == null || r[1].isEmpty() ? Domains.displayHost(url) : r[1];
                root.addView(Ui.row(a, bookmarks ? R.drawable.ic_bookmark : R.drawable.ic_history,
                        title, Domains.displayHost(url), null, v -> h.openUrl(url)));
            }
        }
        return Ui.sheet(a, root);
    }

    // ------------------------------------------------------------------------------------------
    // Tabs
    // ------------------------------------------------------------------------------------------
    static Dialog tabsSheet(Activity a, Host h, List<String[]> tabs, int current) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.tabs_title, tabs.size()),
                a.getString(R.string.tabs_sub)));
        TextView newTab = Ui.pill(a, a.getString(R.string.new_tab), true, v -> h.newTab());
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        np.setMargins(0, Ui.dp(a, 6), 0, Ui.dp(a, 10));
        root.addView(newTab, np);
        for (int i = 0; i < tabs.size(); i++) {
            String[] t = tabs.get(i);
            String title = t[0] == null || t[0].isEmpty() ? Domains.displayHost(t[1]) : t[0];
            LinearLayout r = Ui.row(a, i == current ? R.drawable.ic_check : R.drawable.ic_file,
                    title, Domains.displayHost(t[1]), null, v -> h.openUrl(t[1]));
            root.addView(r);
        }
        return Ui.sheet(a, root);
    }

    // ------------------------------------------------------------------------------------------
    // Settings
    // ------------------------------------------------------------------------------------------
    static Dialog settings(Activity a, Host h) {
        Prefs p = BadrApp.get().prefs();
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.settings_title), a.getString(R.string.settings_sub)));

        root.addView(Ui.sectionTitle(a, a.getString(R.string.settings_privacy)));
        LinearLayout card = Ui.card(a);
        card.addView(Ui.switchRow(a, R.drawable.ic_shield, a.getString(R.string.settings_adblock),
                a.getString(R.string.settings_adblock_sub), p.adblock(), on -> h.setAdblock(on)));
        card.addView(Ui.divider(a));
        card.addView(Ui.switchRow(a, R.drawable.ic_lock, a.getString(R.string.settings_https),
                a.getString(R.string.settings_https_sub), p.httpsOnly(), on -> h.setHttpsOnly(on)));
        card.addView(Ui.divider(a));
        card.addView(Ui.switchRow(a, R.drawable.ic_code, a.getString(R.string.settings_js),
                a.getString(R.string.settings_js_sub), p.jsGlobal(), on -> h.setJs(on)));
        card.addView(Ui.divider(a));
        card.addView(Ui.switchRow(a, R.drawable.ic_cookie, a.getString(R.string.settings_cookies),
                a.getString(R.string.settings_cookies_sub), p.cookiesGlobal(), on -> h.setCookies(on)));
        card.addView(Ui.divider(a));
        card.addView(Ui.switchRow(a, R.drawable.ic_eye, a.getString(R.string.settings_incognito),
                a.getString(R.string.settings_incognito_sub), p.incognito(), on -> {
                    p.incognito(on);
                    h.reload();
                }));
        card.addView(Ui.divider(a));
        card.addView(Ui.switchRow(a, R.drawable.ic_trash, a.getString(R.string.settings_clear_exit),
                a.getString(R.string.settings_clear_exit_sub), p.clearOnExit(), on -> p.clearOnExit(on)));
        card.addView(Ui.divider(a));
        card.addView(Ui.switchRow(a, R.drawable.ic_warning, a.getString(R.string.settings_abuse),
                a.getString(R.string.settings_abuse_sub), p.abuseFilter(), on -> p.abuseFilter(on)));
        root.addView(card);

        root.addView(Ui.sectionTitle(a, a.getString(R.string.settings_network)));
        LinearLayout card2 = Ui.card(a);
        card2.addView(Ui.row(a, R.drawable.ic_onion, a.getString(R.string.tor_title),
                a.getString(R.string.tor_sub), Ui.chevron(a), v -> torSettings(a, h)));
        card2.addView(Ui.divider(a));
        card2.addView(Ui.row(a, R.drawable.ic_search, a.getString(R.string.settings_search),
                searchLabel(a, p.searchEngine()), Ui.chevron(a), v -> searchEngineSheet(a, h)));
        card2.addView(Ui.divider(a));
        card2.addView(Ui.row(a, R.drawable.ic_search, a.getString(R.string.settings_onion_search),
                OnionSearch.engine(p.onionEngine()).name, Ui.chevron(a), v -> onionEngineSheet(a, h)));
        root.addView(card2);

        root.addView(Ui.sectionTitle(a, a.getString(R.string.settings_dev)));
        LinearLayout card3 = Ui.card(a);
        card3.addView(Ui.switchRow(a, R.drawable.ic_console, a.getString(R.string.settings_console),
                a.getString(R.string.settings_console_sub), p.consoleEnabled(), on -> p.consoleEnabled(on)));
        card3.addView(Ui.divider(a));
        card3.addView(Ui.row(a, R.drawable.ic_console, a.getString(R.string.console_title),
                a.getString(R.string.console_sub), Ui.chevron(a), v -> h.openConsole()));
        root.addView(card3);

        root.addView(Ui.sectionTitle(a, a.getString(R.string.settings_data)));
        LinearLayout card4 = Ui.card(a);
        card4.addView(Ui.row(a, R.drawable.ic_bookmark, a.getString(R.string.bookmarks_title), null,
                Ui.chevron(a), v -> h.openBookmarks()));
        card4.addView(Ui.divider(a));
        card4.addView(Ui.row(a, R.drawable.ic_history, a.getString(R.string.history_title), null,
                Ui.chevron(a), v -> h.openHistory()));
        card4.addView(Ui.divider(a));
        card4.addView(Ui.row(a, R.drawable.ic_download, a.getString(R.string.downloads_title), null,
                Ui.chevron(a), v -> h.openDownloads()));
        root.addView(card4);
        return Ui.sheet(a, root);
    }

    private static String searchLabel(Context c, String url) {
        if (Prefs.SEARCH_DDG.equals(url)) return "DuckDuckGo";
        if (Prefs.SEARCH_BRAVE.equals(url)) return "Brave Search";
        if (Prefs.SEARCH_STARTPAGE.equals(url)) return "Startpage";
        if (Prefs.SEARCH_QWANT.equals(url)) return "Qwant";
        return "Google";
    }

    static Dialog searchEngineSheet(Activity a, Host h) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.settings_search), a.getString(R.string.settings_search_sub)));
        String cur = BadrApp.get().prefs().searchEngine();
        String[][] engines = {
                {"Google", Prefs.SEARCH_GOOGLE}, {"DuckDuckGo", Prefs.SEARCH_DDG}, {"Brave Search", Prefs.SEARCH_BRAVE},
                {"Startpage", Prefs.SEARCH_STARTPAGE}, {"Qwant", Prefs.SEARCH_QWANT}};
        for (String[] e : engines) {
            root.addView(Ui.row(a, e[1].equals(cur) ? R.drawable.ic_check : 0, e[0], null, null, v -> {
                BadrApp.get().prefs().searchEngine(e[1]);
            }));
        }
        return Ui.sheet(a, root);
    }

    static Dialog onionEngineSheet(Activity a, Host h) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.settings_onion_search),
                a.getString(R.string.settings_onion_search_sub)));
        String cur = BadrApp.get().prefs().onionEngine();
        for (OnionSearch.Engine e : OnionSearch.ENGINES) {
            root.addView(Ui.row(a, e.id.equals(cur) ? R.drawable.ic_check : R.drawable.ic_onion, e.name,
                    OnionSearch.hostOf(e), null, v -> BadrApp.get().prefs().onionEngine(e.id)));
        }
        return Ui.sheet(a, root);
    }

    // ------------------------------------------------------------------------------------------
    // Onion search results
    // ------------------------------------------------------------------------------------------
    static Dialog onionResults(Activity a, Host h, String query, List<OnionSearch.Result> results, String engineName) {
        LinearLayout root = Ui.vbox(a);
        root.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 8));
        root.addView(Ui.sheetHeader(a, a.getString(R.string.onion_results_title, query),
                a.getString(R.string.onion_results_sub, engineName, results.size())));
        if (results.isEmpty()) {
            TextView none = Ui.text(a, a.getString(R.string.onion_results_none), 14, Ui.TEXT2, false);
            none.setPadding(Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 12));
            root.addView(none);
        } else {
            for (OnionSearch.Result r : results) {
                LinearLayout item = Ui.vbox(a);
                item.setPadding(Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10));
                TextView t = Ui.text(a, r.title, 16, Ui.GOLD_LIGHT, true);
                item.addView(t);
                TextView u = Ui.text(a, Domains.displayHost(r.url), 12, Ui.TEXT3, false);
                u.setPadding(0, Ui.dp(a, 3), 0, 0);
                item.addView(u);
                if (!TextUtils.isEmpty(r.snippet)) {
                    TextView s = Ui.text(a, r.snippet, 13, Ui.TEXT2, false);
                    s.setPadding(0, Ui.dp(a, 4), 0, 0);
                    item.addView(s);
                }
                item.setOnClickListener(v -> h.openUrl(r.url));
                item.setBackground(Ui.ripple(null));
                root.addView(item);
            }
        }
        return Ui.sheet(a, root);
    }

    // ------------------------------------------------------------------------------------------
    // Helpers used by the activity
    // ------------------------------------------------------------------------------------------
    static void copy(Context c, String text) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("url", text));
            Ui.toast(c, c.getString(R.string.copied));
        }
    }

    static void share(Context c, String url, String title) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, url);
        i.putExtra(Intent.EXTRA_SUBJECT, title);
        c.startActivity(Intent.createChooser(i, c.getString(R.string.share)));
    }

    static void openExternal(Context c, String url) {
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Ui.toast(c, e.getMessage() == null ? url : e.getMessage());
        }
    }

    static Switch findSwitch(View row) {
        return null;
    }
}
