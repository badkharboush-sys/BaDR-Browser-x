package com.badr.browser;

import android.app.Application;
import android.webkit.WebView;

/** Application object: holds the shared singletons. */
public final class BadrApp extends Application {
    private static BadrApp instance;
    private Db db;
    private Prefs prefs;
    private Blocklist blocklist;
    private Tor tor;
    private Proxy proxy;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        db = new Db(this);
        prefs = new Prefs(this);
        tor = new Tor(this, prefs);
        proxy = new Proxy();
        // Warm up WebView early so the first page is fast.
        try {
            WebView.enableSlowWholeDocumentDraw();
        } catch (Throwable ignored) {
        }
        new Thread(() -> blocklist = Blocklist.load(this), "badr-blocklist").start();
    }

    static BadrApp get() {
        return instance;
    }

    Db db() {
        return db;
    }

    Prefs prefs() {
        return prefs;
    }

    Tor tor() {
        return tor;
    }

    Proxy proxy() {
        return proxy;
    }

    Blocklist blocklist() {
        return blocklist;
    }
}
