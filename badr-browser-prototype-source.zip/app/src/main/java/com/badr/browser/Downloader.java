package com.badr.browser;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * Downloads files over Tor (or direct) into the app's own storage, with progress.
 * Files land in the public Downloads folder through MediaStore on Android 10+.
 */
final class Downloader {
    interface Callback {
        void onProgress(long done, long total);

        void onDone(File file, String name, long size);

        void onError(String message);
    }

    private static final Map<Long, Thread> RUNNING = new HashMap<>();

    private Downloader() {}

    static void cancel(long id) {
        Thread t;
        synchronized (RUNNING) {
            t = RUNNING.get(id);
        }
        if (t != null) t.interrupt();
    }

    static void download(Context c, long id, String url, String name, boolean onion, int socksPort, Callback cb) {
        Thread t = new Thread(() -> run(c, id, url, name, onion, socksPort, cb), "badr-dl-" + id);
        synchronized (RUNNING) {
            RUNNING.put(id, t);
        }
        t.start();
    }

    private static void run(Context c, long id, String url, String name, boolean onion, int socksPort, Callback cb) {
        Handler main = new Handler(Looper.getMainLooper());
        File out = new File(c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name);
        try {
            if (out.getParentFile() != null) out.getParentFile().mkdirs();
            HttpURLConnection conn;
            if (onion) {
                Proxy proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress("127.0.0.1", socksPort));
                conn = (HttpURLConnection) new URL(url).openConnection(proxy);
            } else {
                conn = (HttpURLConnection) new URL(url).openConnection();
            }
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "BaDR/1.0");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) {
                main.post(() -> cb.onError("HTTP " + code));
                return;
            }
            long total = conn.getContentLengthLong();
            try (InputStream in = conn.getInputStream(); OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[16384];
                long done = 0;
                int n;
                while ((n = in.read(buf)) >= 0) {
                    if (Thread.currentThread().isInterrupted()) {
                        out.delete();
                        main.post(() -> cb.onError("Cancelled"));
                        return;
                    }
                    os.write(buf, 0, n);
                    done += n;
                    final long d = done;
                    final long t = total;
                    main.post(() -> cb.onProgress(d, t));
                }
            }
            final long size = out.length();
            main.post(() -> cb.onDone(out, name, size));
        } catch (Exception e) {
            String msg = e.getMessage();
            main.post(() -> cb.onError(msg == null ? "Download failed" : msg));
        } finally {
            synchronized (RUNNING) {
                RUNNING.remove(id);
            }
        }
    }

    static Intent openIntent(Context c, File f) {
        Uri uri = FileProvider.getUriForFile(c, c.getPackageName() + ".files", f);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, guessMime(f.getName()));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return i;
    }

    static String guessMime(String name) {
        String e = Domains.extension(name);
        switch (e) {
            case "pdf": return "application/pdf";
            case "txt": case "log": return "text/plain";
            case "html": case "htm": return "text/html";
            case "json": return "application/json";
            case "xml": return "application/xml";
            case "zip": return "application/zip";
            case "apk": return "application/vnd.android.package-archive";
            case "mp3": return "audio/mpeg";
            case "mp4": return "video/mp4";
            case "mkv": return "video/x-matroska";
            case "webm": return "video/webm";
            case "jpg": case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "webp": return "image/webp";
            case "svg": return "image/svg+xml";
            case "doc": return "application/msword";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "xls": return "application/vnd.ms-excel";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "ppt": return "application/vnd.ms-powerpoint";
            case "pptx": return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            case "epub": return "application/epub+zip";
            default: return "*/*";
        }
    }
}
