package com.badr.browser;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Download detector + downloader.
 *
 * The WebView cannot download files by itself, so we watch for the signals that a download is starting:
 *   - the DownloadListener (Content-Disposition: attachment / unknown content type)
 *   - a URL whose path ends in a known file extension
 *   - a response with a non-HTML content type
 * and then fetch the file ourselves (through Tor when the site is onion-routed).
 */
final class Downloads {
    private static final Set<String> EXT = new HashSet<>();
    static {
        String[] ext = {"apk", "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "pdf", "doc", "docx", "xls", "xlsx",
                "ppt", "pptx", "txt", "rtf", "odt", "ods", "odp", "csv", "json", "xml", "html", "htm",
                "mp3", "wav", "ogg", "flac", "m4a", "aac", "opus", "mp4", "mkv", "webm", "mov", "avi", "wmv", "flv",
                "jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "ico", "tif", "tiff", "heic", "heif",
                "epub", "mobi", "azw", "azw3", "djvu", "chm", "iso", "img", "dmg", "bin", "deb", "rpm", "exe",
                "msi", "jar", "class", "wasm", "ttf", "otf", "woff", "woff2", "eot", "db", "sqlite", "sql",
                "log", "pem", "key", "crt", "torrent", "magnet", "nfo", "srt", "vtt", "ass", "sub"};
        for (String e : ext) EXT.add(e);
    }

    private Downloads() {}

    static boolean looksLikeFile(String url) {
        String e = Domains.extension(url);
        return !e.isEmpty() && EXT.contains(e);
    }

    static boolean isMedia(String url) {
        String e = Domains.extension(url);
        return e.equals("mp3") || e.equals("wav") || e.equals("ogg") || e.equals("flac") || e.equals("m4a")
                || e.equals("aac") || e.equals("opus") || e.equals("mp4") || e.equals("mkv") || e.equals("webm")
                || e.equals("mov") || e.equals("avi") || e.equals("wmv") || e.equals("flv");
    }

    static String fileName(String url, String contentDisposition, String mime) {
        String name = null;
        if (contentDisposition != null) {
            name = param(contentDisposition, "filename*");
            if (name != null) name = decodeRfc5987(name);
            if (name == null) name = param(contentDisposition, "filename");
            if (name != null) name = name.replace("\"", "").trim();
        }
        if (name == null || name.isEmpty()) {
            String p = Domains.stripQuery(url);
            int slash = p.lastIndexOf('/');
            name = slash >= 0 ? p.substring(slash + 1) : p;
            try {
                name = java.net.URLDecoder.decode(name, "UTF-8");
            } catch (Exception ignored) {
            }
        }
        if (name == null || name.isEmpty() || name.equals("/")) name = "download";
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
        if (!name.contains(".") && mime != null) {
            String e = mimeToExt(mime);
            if (e != null) name = name + "." + e;
        }
        return name;
    }

    private static String param(String header, String key) {
        String lower = header.toLowerCase(Locale.ROOT);
        int i = lower.indexOf(key + "=");
        if (i < 0) return null;
        int start = i + key.length() + 1;
        int end = header.length();
        for (int j = start; j < header.length(); j++) {
            if (header.charAt(j) == ';') {
                end = j;
                break;
            }
        }
        return header.substring(start, end).trim();
    }

    private static String decodeRfc5987(String v) {
        // UTF-8''name%20with%20spaces
        int q1 = v.indexOf('\'');
        int q2 = q1 >= 0 ? v.indexOf('\'', q1 + 1) : -1;
        if (q1 < 0 || q2 < 0) return null;
        try {
            return java.net.URLDecoder.decode(v.substring(q2 + 1), "UTF-8");
        } catch (Exception e) {
            return null;
        }
    }

    static String mimeToExt(String mime) {
        if (mime == null) return null;
        switch (mime.toLowerCase(Locale.ROOT)) {
            case "application/pdf": return "pdf";
            case "application/zip": return "zip";
            case "application/octet-stream": return "bin";
            case "application/json": return "json";
            case "text/plain": return "txt";
            case "text/html": return "html";
            case "image/png": return "png";
            case "image/jpeg": return "jpg";
            case "image/gif": return "gif";
            case "image/webp": return "webp";
            case "audio/mpeg": return "mp3";
            case "video/mp4": return "mp4";
            case "application/vnd.android.package-archive": return "apk";
            case "application/msword": return "doc";
            case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": return "docx";
            default: return null;
        }
    }

    static boolean isAttachment(String contentDisposition, String mime) {
        if (contentDisposition != null && contentDisposition.toLowerCase(Locale.ROOT).contains("attachment")) return true;
        if (mime == null) return false;
        String m = mime.toLowerCase(Locale.ROOT);
        return !(m.startsWith("text/html") || m.startsWith("text/css") || m.startsWith("text/javascript")
                || m.startsWith("application/javascript") || m.startsWith("image/svg") || m.equals("application/xhtml+xml"));
    }

    /** Start a system DownloadManager download (clearnet only). */
    static long startSystem(Context c, String url, String name) {
        DownloadManager dm = (DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm == null) return -1;
        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
        r.setTitle(name);
        r.setDescription(url);
        r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
        r.setAllowedOverMetered(true);
        r.setAllowedOverRoaming(true);
        try {
            return dm.enqueue(r);
        } catch (Exception e) {
            return -1;
        }
    }

    static Intent viewIntent(Context c, String url, String mime) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.parse(url), mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return i;
    }
}
